﻿
namespace Hotel
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.cn = new System.Data.OleDb.OleDbConnection();
            this.AddR = new System.Windows.Forms.TabControl();
            this.RoomInfo = new System.Windows.Forms.TabPage();
            this.dg = new System.Windows.Forms.DataGrid();
            this.ShowCat = new System.Windows.Forms.Button();
            this.CategName = new System.Windows.Forms.Label();
            this.table = new System.Windows.Forms.ComboBox();
            this.AddCatT = new System.Windows.Forms.TabPage();
            this.NumberRooms = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.Bathroom = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.TV = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.CatName = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.AddCateg = new System.Windows.Forms.Button();
            this.CostNight = new System.Windows.Forms.TextBox();
            this.CostperNight = new System.Windows.Forms.Label();
            this.RoomCap = new System.Windows.Forms.TextBox();
            this.RoomL = new System.Windows.Forms.Label();
            this.ViewServi = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.CatId = new System.Windows.Forms.TextBox();
            this.Label = new System.Windows.Forms.Label();
            this.RoomIdAdd = new System.Windows.Forms.TextBox();
            this.AddRoom = new System.Windows.Forms.Button();
            this.AService = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.ServName = new System.Windows.Forms.TextBox();
            this.ResId = new System.Windows.Forms.Label();
            this.CostSer = new System.Windows.Forms.TextBox();
            this.AddServ = new System.Windows.Forms.Button();
            this.AddE = new System.Windows.Forms.TabPage();
            this.label24 = new System.Windows.Forms.Label();
            this.DE = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.ME = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.YE = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.DB = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.MB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.YearB = new System.Windows.Forms.TextBox();
            this.AddEmpl = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.NameE = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Surname = new System.Windows.Forms.TextBox();
            this.MyOrder = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.status = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.description = new System.Windows.Forms.TextBox();
            this.AddStatus = new System.Windows.Forms.Button();
            this.Request = new System.Windows.Forms.TabPage();
            this.SelectId = new System.Windows.Forms.ComboBox();
            this.save = new System.Windows.Forms.Button();
            this.SelectStatus = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SelectEmpl = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ShowRequests = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Remove = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.DD = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.MD = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.YD = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.NameDel = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SurnameDel = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.AddR.SuspendLayout();
            this.RoomInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
            this.AddCatT.SuspendLayout();
            this.ViewServi.SuspendLayout();
            this.AService.SuspendLayout();
            this.AddE.SuspendLayout();
            this.MyOrder.SuspendLayout();
            this.Request.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cn
            // 
            this.cn.ConnectionString = "Provider=SQLNCLI11;Data Source=LAPTOP-8JAMNBRV;Integrated Security=SSPI;Initial C" +
    "atalog=Hotel";
            // 
            // AddR
            // 
            this.AddR.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.AddR.Controls.Add(this.RoomInfo);
            this.AddR.Controls.Add(this.AddCatT);
            this.AddR.Controls.Add(this.ViewServi);
            this.AddR.Controls.Add(this.AService);
            this.AddR.Controls.Add(this.AddE);
            this.AddR.Controls.Add(this.MyOrder);
            this.AddR.Controls.Add(this.Request);
            this.AddR.Controls.Add(this.tabPage1);
            this.AddR.Controls.Add(this.tabPage2);
            this.AddR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddR.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddR.ItemSize = new System.Drawing.Size(400, 41);
            this.AddR.Location = new System.Drawing.Point(0, 0);
            this.AddR.Multiline = true;
            this.AddR.Name = "AddR";
            this.AddR.SelectedIndex = 0;
            this.AddR.Size = new System.Drawing.Size(1397, 779);
            this.AddR.TabIndex = 1;
            // 
            // RoomInfo
            // 
            this.RoomInfo.AutoScroll = true;
            this.RoomInfo.BackColor = System.Drawing.Color.OliveDrab;
            this.RoomInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RoomInfo.Controls.Add(this.dg);
            this.RoomInfo.Controls.Add(this.ShowCat);
            this.RoomInfo.Controls.Add(this.CategName);
            this.RoomInfo.Controls.Add(this.table);
            this.RoomInfo.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.RoomInfo.ImageKey = "(отсутствует)";
            this.RoomInfo.Location = new System.Drawing.Point(4, 89);
            this.RoomInfo.Name = "RoomInfo";
            this.RoomInfo.Padding = new System.Windows.Forms.Padding(3);
            this.RoomInfo.Size = new System.Drawing.Size(1389, 686);
            this.RoomInfo.TabIndex = 0;
            this.RoomInfo.Text = "Information";
            // 
            // dg
            // 
            this.dg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dg.DataMember = "";
            this.dg.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dg.Location = new System.Drawing.Point(199, 177);
            this.dg.Name = "dg";
            this.dg.ReadOnly = true;
            this.dg.RowHeaderWidth = 70;
            this.dg.Size = new System.Drawing.Size(1135, 468);
            this.dg.TabIndex = 16;
            // 
            // ShowCat
            // 
            this.ShowCat.BackColor = System.Drawing.Color.Silver;
            this.ShowCat.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowCat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShowCat.Location = new System.Drawing.Point(1131, 101);
            this.ShowCat.Name = "ShowCat";
            this.ShowCat.Size = new System.Drawing.Size(148, 43);
            this.ShowCat.TabIndex = 15;
            this.ShowCat.Text = "Show";
            this.ShowCat.UseVisualStyleBackColor = false;
            this.ShowCat.Click += new System.EventHandler(this.ShowCat_Click);
            // 
            // CategName
            // 
            this.CategName.AutoSize = true;
            this.CategName.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CategName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.CategName.Location = new System.Drawing.Point(229, 103);
            this.CategName.Name = "CategName";
            this.CategName.Size = new System.Drawing.Size(253, 40);
            this.CategName.TabIndex = 3;
            this.CategName.Text = "Table name";
            // 
            // table
            // 
            this.table.BackColor = System.Drawing.Color.Silver;
            this.table.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.table.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.table.FormattingEnabled = true;
            this.table.Items.AddRange(new object[] {
            "Booking",
            "Client info",
            "Room info",
            "Categories info",
            "Orders",
            "About orders",
            "Service catalog",
            "Service request",
            "Product list",
            "About status",
            "Employees"});
            this.table.Location = new System.Drawing.Point(602, 100);
            this.table.Name = "table";
            this.table.Size = new System.Drawing.Size(457, 48);
            this.table.TabIndex = 2;
            // 
            // AddCatT
            // 
            this.AddCatT.BackColor = System.Drawing.Color.OliveDrab;
            this.AddCatT.Controls.Add(this.NumberRooms);
            this.AddCatT.Controls.Add(this.label19);
            this.AddCatT.Controls.Add(this.Bathroom);
            this.AddCatT.Controls.Add(this.label20);
            this.AddCatT.Controls.Add(this.TV);
            this.AddCatT.Controls.Add(this.label21);
            this.AddCatT.Controls.Add(this.CatName);
            this.AddCatT.Controls.Add(this.label22);
            this.AddCatT.Controls.Add(this.AddCateg);
            this.AddCatT.Controls.Add(this.CostNight);
            this.AddCatT.Controls.Add(this.CostperNight);
            this.AddCatT.Controls.Add(this.RoomCap);
            this.AddCatT.Controls.Add(this.RoomL);
            this.AddCatT.ForeColor = System.Drawing.Color.Ivory;
            this.AddCatT.Location = new System.Drawing.Point(4, 89);
            this.AddCatT.Name = "AddCatT";
            this.AddCatT.Padding = new System.Windows.Forms.Padding(3);
            this.AddCatT.Size = new System.Drawing.Size(1389, 686);
            this.AddCatT.TabIndex = 1;
            this.AddCatT.Text = "Add categories";
            // 
            // NumberRooms
            // 
            this.NumberRooms.BackColor = System.Drawing.Color.Silver;
            this.NumberRooms.Location = new System.Drawing.Point(944, 330);
            this.NumberRooms.Name = "NumberRooms";
            this.NumberRooms.Size = new System.Drawing.Size(272, 40);
            this.NumberRooms.TabIndex = 24;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(395, 336);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(322, 34);
            this.label19.TabIndex = 23;
            this.label19.Text = "Number of rooms";
            // 
            // Bathroom
            // 
            this.Bathroom.BackColor = System.Drawing.Color.Silver;
            this.Bathroom.Location = new System.Drawing.Point(944, 271);
            this.Bathroom.Name = "Bathroom";
            this.Bathroom.Size = new System.Drawing.Size(272, 40);
            this.Bathroom.TabIndex = 22;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(395, 277);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(513, 34);
            this.label20.TabIndex = 21;
            this.label20.Text = "The presence of a bathroom";
            // 
            // TV
            // 
            this.TV.BackColor = System.Drawing.Color.Silver;
            this.TV.Location = new System.Drawing.Point(944, 213);
            this.TV.Name = "TV";
            this.TV.Size = new System.Drawing.Size(272, 40);
            this.TV.TabIndex = 20;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(395, 219);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(370, 34);
            this.label21.TabIndex = 19;
            this.label21.Text = "The presence of a TV";
            // 
            // CatName
            // 
            this.CatName.BackColor = System.Drawing.Color.Silver;
            this.CatName.Location = new System.Drawing.Point(944, 154);
            this.CatName.Name = "CatName";
            this.CatName.Size = new System.Drawing.Size(272, 40);
            this.CatName.TabIndex = 18;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(395, 160);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(291, 34);
            this.label22.TabIndex = 17;
            this.label22.Text = "Category name";
            // 
            // AddCateg
            // 
            this.AddCateg.BackColor = System.Drawing.Color.Silver;
            this.AddCateg.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddCateg.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddCateg.Location = new System.Drawing.Point(606, 580);
            this.AddCateg.Name = "AddCateg";
            this.AddCateg.Size = new System.Drawing.Size(420, 49);
            this.AddCateg.TabIndex = 16;
            this.AddCateg.Text = "Add";
            this.AddCateg.UseVisualStyleBackColor = false;
            this.AddCateg.Click += new System.EventHandler(this.AddCateg_Click);
            // 
            // CostNight
            // 
            this.CostNight.BackColor = System.Drawing.Color.Silver;
            this.CostNight.Location = new System.Drawing.Point(944, 449);
            this.CostNight.Name = "CostNight";
            this.CostNight.Size = new System.Drawing.Size(272, 40);
            this.CostNight.TabIndex = 9;
            // 
            // CostperNight
            // 
            this.CostperNight.AutoSize = true;
            this.CostperNight.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostperNight.Location = new System.Drawing.Point(395, 455);
            this.CostperNight.Name = "CostperNight";
            this.CostperNight.Size = new System.Drawing.Size(274, 34);
            this.CostperNight.TabIndex = 8;
            this.CostperNight.Text = "Cost per night";
            // 
            // RoomCap
            // 
            this.RoomCap.BackColor = System.Drawing.Color.Silver;
            this.RoomCap.Location = new System.Drawing.Point(944, 389);
            this.RoomCap.Name = "RoomCap";
            this.RoomCap.Size = new System.Drawing.Size(272, 40);
            this.RoomCap.TabIndex = 1;
            // 
            // RoomL
            // 
            this.RoomL.AutoSize = true;
            this.RoomL.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomL.Location = new System.Drawing.Point(395, 395);
            this.RoomL.Name = "RoomL";
            this.RoomL.Size = new System.Drawing.Size(286, 34);
            this.RoomL.TabIndex = 0;
            this.RoomL.Text = "Room capacity";
            // 
            // ViewServi
            // 
            this.ViewServi.BackColor = System.Drawing.Color.OliveDrab;
            this.ViewServi.Controls.Add(this.label1);
            this.ViewServi.Controls.Add(this.CatId);
            this.ViewServi.Controls.Add(this.Label);
            this.ViewServi.Controls.Add(this.RoomIdAdd);
            this.ViewServi.Controls.Add(this.AddRoom);
            this.ViewServi.Location = new System.Drawing.Point(4, 89);
            this.ViewServi.Name = "ViewServi";
            this.ViewServi.Padding = new System.Windows.Forms.Padding(3);
            this.ViewServi.Size = new System.Drawing.Size(1389, 686);
            this.ViewServi.TabIndex = 4;
            this.ViewServi.Text = "Add Room";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(374, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 36);
            this.label1.TabIndex = 27;
            this.label1.Text = "Category Id";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // CatId
            // 
            this.CatId.BackColor = System.Drawing.Color.Silver;
            this.CatId.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatId.Location = new System.Drawing.Point(798, 322);
            this.CatId.Name = "CatId";
            this.CatId.Size = new System.Drawing.Size(344, 44);
            this.CatId.TabIndex = 26;
            this.CatId.TextChanged += new System.EventHandler(this.CatId_TextChanged);
            // 
            // Label
            // 
            this.Label.AutoSize = true;
            this.Label.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label.Location = new System.Drawing.Point(374, 243);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(171, 36);
            this.Label.TabIndex = 25;
            this.Label.Text = "Room id";
            this.Label.Click += new System.EventHandler(this.Label_Click);
            // 
            // RoomIdAdd
            // 
            this.RoomIdAdd.BackColor = System.Drawing.Color.Silver;
            this.RoomIdAdd.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomIdAdd.Location = new System.Drawing.Point(798, 235);
            this.RoomIdAdd.Name = "RoomIdAdd";
            this.RoomIdAdd.Size = new System.Drawing.Size(344, 44);
            this.RoomIdAdd.TabIndex = 24;
            this.RoomIdAdd.TextChanged += new System.EventHandler(this.RoomIdAdd_TextChanged);
            // 
            // AddRoom
            // 
            this.AddRoom.BackColor = System.Drawing.Color.Silver;
            this.AddRoom.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddRoom.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddRoom.Location = new System.Drawing.Point(510, 473);
            this.AddRoom.Name = "AddRoom";
            this.AddRoom.Size = new System.Drawing.Size(456, 83);
            this.AddRoom.TabIndex = 23;
            this.AddRoom.Text = "Add Room";
            this.AddRoom.UseVisualStyleBackColor = false;
            this.AddRoom.Click += new System.EventHandler(this.AddRoom_Click);
            // 
            // AService
            // 
            this.AService.BackColor = System.Drawing.Color.OliveDrab;
            this.AService.Controls.Add(this.label3);
            this.AService.Controls.Add(this.ServName);
            this.AService.Controls.Add(this.ResId);
            this.AService.Controls.Add(this.CostSer);
            this.AService.Controls.Add(this.AddServ);
            this.AService.Location = new System.Drawing.Point(4, 89);
            this.AService.Name = "AService";
            this.AService.Padding = new System.Windows.Forms.Padding(3);
            this.AService.Size = new System.Drawing.Size(1389, 686);
            this.AService.TabIndex = 2;
            this.AService.Text = "Add service";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(348, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(310, 36);
            this.label3.TabIndex = 27;
            this.label3.Text = "Name Of Service";
            // 
            // ServName
            // 
            this.ServName.BackColor = System.Drawing.Color.Silver;
            this.ServName.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServName.Location = new System.Drawing.Point(772, 176);
            this.ServName.Name = "ServName";
            this.ServName.Size = new System.Drawing.Size(344, 44);
            this.ServName.TabIndex = 26;
            // 
            // ResId
            // 
            this.ResId.AutoSize = true;
            this.ResId.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ResId.Location = new System.Drawing.Point(348, 284);
            this.ResId.Name = "ResId";
            this.ResId.Size = new System.Drawing.Size(100, 36);
            this.ResId.TabIndex = 25;
            this.ResId.Text = "Cost";
            // 
            // CostSer
            // 
            this.CostSer.BackColor = System.Drawing.Color.Silver;
            this.CostSer.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostSer.Location = new System.Drawing.Point(772, 276);
            this.CostSer.Name = "CostSer";
            this.CostSer.Size = new System.Drawing.Size(344, 44);
            this.CostSer.TabIndex = 24;
            // 
            // AddServ
            // 
            this.AddServ.BackColor = System.Drawing.Color.Silver;
            this.AddServ.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddServ.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddServ.Location = new System.Drawing.Point(573, 440);
            this.AddServ.Name = "AddServ";
            this.AddServ.Size = new System.Drawing.Size(330, 104);
            this.AddServ.TabIndex = 21;
            this.AddServ.Text = "Add service";
            this.AddServ.UseVisualStyleBackColor = false;
            this.AddServ.Click += new System.EventHandler(this.AddServ_Click);
            // 
            // AddE
            // 
            this.AddE.BackColor = System.Drawing.Color.OliveDrab;
            this.AddE.Controls.Add(this.label24);
            this.AddE.Controls.Add(this.DE);
            this.AddE.Controls.Add(this.label25);
            this.AddE.Controls.Add(this.ME);
            this.AddE.Controls.Add(this.label26);
            this.AddE.Controls.Add(this.YE);
            this.AddE.Controls.Add(this.label23);
            this.AddE.Controls.Add(this.DB);
            this.AddE.Controls.Add(this.label12);
            this.AddE.Controls.Add(this.MB);
            this.AddE.Controls.Add(this.label2);
            this.AddE.Controls.Add(this.label14);
            this.AddE.Controls.Add(this.YearB);
            this.AddE.Controls.Add(this.AddEmpl);
            this.AddE.Controls.Add(this.label13);
            this.AddE.Controls.Add(this.label10);
            this.AddE.Controls.Add(this.NameE);
            this.AddE.Controls.Add(this.label11);
            this.AddE.Controls.Add(this.Surname);
            this.AddE.Location = new System.Drawing.Point(4, 89);
            this.AddE.Name = "AddE";
            this.AddE.Padding = new System.Windows.Forms.Padding(3);
            this.AddE.Size = new System.Drawing.Size(1389, 686);
            this.AddE.TabIndex = 3;
            this.AddE.Text = "Add Employee";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Castellar", 12F);
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Location = new System.Drawing.Point(1062, 414);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(61, 25);
            this.label24.TabIndex = 51;
            this.label24.Text = "Day";
            // 
            // DE
            // 
            this.DE.BackColor = System.Drawing.Color.Silver;
            this.DE.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DE.Location = new System.Drawing.Point(1050, 442);
            this.DE.Name = "DE";
            this.DE.Size = new System.Drawing.Size(95, 44);
            this.DE.TabIndex = 50;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Castellar", 12F);
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Location = new System.Drawing.Point(927, 414);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 25);
            this.label25.TabIndex = 49;
            this.label25.Text = "Month";
            // 
            // ME
            // 
            this.ME.BackColor = System.Drawing.Color.Silver;
            this.ME.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ME.Location = new System.Drawing.Point(932, 442);
            this.ME.Name = "ME";
            this.ME.Size = new System.Drawing.Size(95, 44);
            this.ME.TabIndex = 48;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Castellar", 12F);
            this.label26.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label26.Location = new System.Drawing.Point(825, 414);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 25);
            this.label26.TabIndex = 47;
            this.label26.Text = "Year";
            // 
            // YE
            // 
            this.YE.BackColor = System.Drawing.Color.Silver;
            this.YE.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YE.Location = new System.Drawing.Point(813, 442);
            this.YE.Name = "YE";
            this.YE.Size = new System.Drawing.Size(95, 44);
            this.YE.TabIndex = 46;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Castellar", 12F);
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Location = new System.Drawing.Point(1062, 300);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(61, 25);
            this.label23.TabIndex = 45;
            this.label23.Text = "Day";
            // 
            // DB
            // 
            this.DB.BackColor = System.Drawing.Color.Silver;
            this.DB.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DB.Location = new System.Drawing.Point(1050, 328);
            this.DB.Name = "DB";
            this.DB.Size = new System.Drawing.Size(95, 44);
            this.DB.TabIndex = 44;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Castellar", 12F);
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(927, 300);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 25);
            this.label12.TabIndex = 43;
            this.label12.Text = "Month";
            // 
            // MB
            // 
            this.MB.BackColor = System.Drawing.Color.Silver;
            this.MB.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MB.Location = new System.Drawing.Point(932, 328);
            this.MB.Name = "MB";
            this.MB.Size = new System.Drawing.Size(95, 44);
            this.MB.TabIndex = 42;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Castellar", 12F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(825, 300);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 25);
            this.label2.TabIndex = 41;
            this.label2.Text = "Year";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(319, 336);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(273, 36);
            this.label14.TabIndex = 39;
            this.label14.Text = "Date of Birth";
            // 
            // YearB
            // 
            this.YearB.BackColor = System.Drawing.Color.Silver;
            this.YearB.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YearB.Location = new System.Drawing.Point(813, 328);
            this.YearB.Name = "YearB";
            this.YearB.Size = new System.Drawing.Size(95, 44);
            this.YearB.TabIndex = 38;
            // 
            // AddEmpl
            // 
            this.AddEmpl.BackColor = System.Drawing.Color.Silver;
            this.AddEmpl.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddEmpl.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddEmpl.Location = new System.Drawing.Point(617, 558);
            this.AddEmpl.Name = "AddEmpl";
            this.AddEmpl.Size = new System.Drawing.Size(323, 70);
            this.AddEmpl.TabIndex = 37;
            this.AddEmpl.Text = "Add";
            this.AddEmpl.UseVisualStyleBackColor = false;
            this.AddEmpl.Click += new System.EventHandler(this.AddEmpl_Click_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(319, 450);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(404, 36);
            this.label13.TabIndex = 36;
            this.label13.Text = "Date of employment";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(319, 216);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 36);
            this.label10.TabIndex = 34;
            this.label10.Text = "Name";
            // 
            // NameE
            // 
            this.NameE.BackColor = System.Drawing.Color.Silver;
            this.NameE.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameE.Location = new System.Drawing.Point(813, 208);
            this.NameE.Name = "NameE";
            this.NameE.Size = new System.Drawing.Size(344, 44);
            this.NameE.TabIndex = 33;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(319, 145);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(178, 36);
            this.label11.TabIndex = 32;
            this.label11.Text = "Surname";
            // 
            // Surname
            // 
            this.Surname.BackColor = System.Drawing.Color.Silver;
            this.Surname.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Surname.Location = new System.Drawing.Point(813, 137);
            this.Surname.Name = "Surname";
            this.Surname.Size = new System.Drawing.Size(344, 44);
            this.Surname.TabIndex = 31;
            // 
            // MyOrder
            // 
            this.MyOrder.BackColor = System.Drawing.Color.OliveDrab;
            this.MyOrder.Controls.Add(this.label15);
            this.MyOrder.Controls.Add(this.status);
            this.MyOrder.Controls.Add(this.label16);
            this.MyOrder.Controls.Add(this.description);
            this.MyOrder.Controls.Add(this.AddStatus);
            this.MyOrder.Location = new System.Drawing.Point(4, 89);
            this.MyOrder.Name = "MyOrder";
            this.MyOrder.Padding = new System.Windows.Forms.Padding(3);
            this.MyOrder.Size = new System.Drawing.Size(1389, 686);
            this.MyOrder.TabIndex = 6;
            this.MyOrder.Text = "Add Status";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(318, 192);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(186, 36);
            this.label15.TabIndex = 32;
            this.label15.Text = "Status Id";
            // 
            // status
            // 
            this.status.BackColor = System.Drawing.Color.Silver;
            this.status.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status.Location = new System.Drawing.Point(742, 184);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(483, 44);
            this.status.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(318, 292);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(236, 36);
            this.label16.TabIndex = 30;
            this.label16.Text = "Description";
            // 
            // description
            // 
            this.description.BackColor = System.Drawing.Color.Silver;
            this.description.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.description.Location = new System.Drawing.Point(742, 284);
            this.description.Name = "description";
            this.description.Size = new System.Drawing.Size(483, 44);
            this.description.TabIndex = 29;
            // 
            // AddStatus
            // 
            this.AddStatus.BackColor = System.Drawing.Color.Silver;
            this.AddStatus.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddStatus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddStatus.Location = new System.Drawing.Point(543, 448);
            this.AddStatus.Name = "AddStatus";
            this.AddStatus.Size = new System.Drawing.Size(330, 104);
            this.AddStatus.TabIndex = 28;
            this.AddStatus.Text = "Add status";
            this.AddStatus.UseVisualStyleBackColor = false;
            this.AddStatus.Click += new System.EventHandler(this.AddStatus_Click);
            // 
            // Request
            // 
            this.Request.BackColor = System.Drawing.Color.OliveDrab;
            this.Request.Controls.Add(this.SelectId);
            this.Request.Controls.Add(this.save);
            this.Request.Controls.Add(this.SelectStatus);
            this.Request.Controls.Add(this.label6);
            this.Request.Controls.Add(this.SelectEmpl);
            this.Request.Controls.Add(this.label4);
            this.Request.Controls.Add(this.label5);
            this.Request.Controls.Add(this.ShowRequests);
            this.Request.Location = new System.Drawing.Point(4, 89);
            this.Request.Name = "Request";
            this.Request.Padding = new System.Windows.Forms.Padding(3);
            this.Request.Size = new System.Drawing.Size(1389, 686);
            this.Request.TabIndex = 7;
            this.Request.Text = "Request";
            // 
            // SelectId
            // 
            this.SelectId.BackColor = System.Drawing.Color.Silver;
            this.SelectId.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SelectId.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectId.FormattingEnabled = true;
            this.SelectId.Items.AddRange(new object[] {
            "Booking",
            "Client info",
            "Room info",
            "Categories info",
            "Orders",
            "About orders",
            "Service catalog",
            "Service request",
            "Product list",
            "About status",
            "Employees"});
            this.SelectId.Location = new System.Drawing.Point(896, 260);
            this.SelectId.Name = "SelectId";
            this.SelectId.Size = new System.Drawing.Size(344, 48);
            this.SelectId.TabIndex = 45;
            this.SelectId.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // save
            // 
            this.save.BackColor = System.Drawing.Color.Silver;
            this.save.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.save.Location = new System.Drawing.Point(692, 520);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(208, 78);
            this.save.TabIndex = 44;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = false;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // SelectStatus
            // 
            this.SelectStatus.BackColor = System.Drawing.Color.Silver;
            this.SelectStatus.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SelectStatus.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectStatus.FormattingEnabled = true;
            this.SelectStatus.Items.AddRange(new object[] {
            "Booking",
            "Client info",
            "Room info",
            "Categories info",
            "Orders",
            "About orders",
            "Service catalog",
            "Service request",
            "Product list",
            "About status",
            "Employees"});
            this.SelectStatus.Location = new System.Drawing.Point(896, 402);
            this.SelectStatus.Name = "SelectStatus";
            this.SelectStatus.Size = new System.Drawing.Size(344, 48);
            this.SelectStatus.TabIndex = 41;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(402, 414);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(260, 36);
            this.label6.TabIndex = 40;
            this.label6.Text = "Select status";
            // 
            // SelectEmpl
            // 
            this.SelectEmpl.BackColor = System.Drawing.Color.Silver;
            this.SelectEmpl.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SelectEmpl.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectEmpl.FormattingEnabled = true;
            this.SelectEmpl.Items.AddRange(new object[] {
            "Booking",
            "Client info",
            "Room info",
            "Categories info",
            "Orders",
            "About orders",
            "Service catalog",
            "Service request",
            "Product list",
            "About status",
            "Employees"});
            this.SelectEmpl.Location = new System.Drawing.Point(896, 331);
            this.SelectEmpl.Name = "SelectEmpl";
            this.SelectEmpl.Size = new System.Drawing.Size(344, 48);
            this.SelectEmpl.TabIndex = 39;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(402, 343);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(371, 36);
            this.label4.TabIndex = 38;
            this.label4.Text = "Select an employee";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(402, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(333, 36);
            this.label5.TabIndex = 36;
            this.label5.Text = "Select Id Request";
            // 
            // ShowRequests
            // 
            this.ShowRequests.BackColor = System.Drawing.Color.Silver;
            this.ShowRequests.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowRequests.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShowRequests.Location = new System.Drawing.Point(517, 97);
            this.ShowRequests.Name = "ShowRequests";
            this.ShowRequests.Size = new System.Drawing.Size(578, 104);
            this.ShowRequests.TabIndex = 22;
            this.ShowRequests.Text = "Show all requests";
            this.ShowRequests.UseVisualStyleBackColor = false;
            this.ShowRequests.Click += new System.EventHandler(this.ShowRequests_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.OliveDrab;
            this.tabPage1.Controls.Add(this.Remove);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.DD);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.MD);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.YD);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.NameDel);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.SurnameDel);
            this.tabPage1.Location = new System.Drawing.Point(4, 89);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1389, 686);
            this.tabPage1.TabIndex = 8;
            this.tabPage1.Text = "Remove employee";
            // 
            // Remove
            // 
            this.Remove.BackColor = System.Drawing.Color.Silver;
            this.Remove.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remove.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Remove.Location = new System.Drawing.Point(627, 484);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(323, 70);
            this.Remove.TabIndex = 53;
            this.Remove.Text = "Remove";
            this.Remove.UseVisualStyleBackColor = false;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Castellar", 12F);
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(1117, 337);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 25);
            this.label9.TabIndex = 52;
            this.label9.Text = "Day";
            // 
            // DD
            // 
            this.DD.BackColor = System.Drawing.Color.Silver;
            this.DD.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DD.Location = new System.Drawing.Point(1105, 365);
            this.DD.Name = "DD";
            this.DD.Size = new System.Drawing.Size(95, 44);
            this.DD.TabIndex = 51;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Castellar", 12F);
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label17.Location = new System.Drawing.Point(982, 337);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 25);
            this.label17.TabIndex = 50;
            this.label17.Text = "Month";
            // 
            // MD
            // 
            this.MD.BackColor = System.Drawing.Color.Silver;
            this.MD.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MD.Location = new System.Drawing.Point(987, 365);
            this.MD.Name = "MD";
            this.MD.Size = new System.Drawing.Size(95, 44);
            this.MD.TabIndex = 49;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Castellar", 12F);
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(880, 337);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 25);
            this.label18.TabIndex = 48;
            this.label18.Text = "Year";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label27.Location = new System.Drawing.Point(374, 373);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(273, 36);
            this.label27.TabIndex = 47;
            this.label27.Text = "Date of Birth";
            // 
            // YD
            // 
            this.YD.BackColor = System.Drawing.Color.Silver;
            this.YD.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YD.Location = new System.Drawing.Point(868, 365);
            this.YD.Name = "YD";
            this.YD.Size = new System.Drawing.Size(95, 44);
            this.YD.TabIndex = 46;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(374, 269);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 36);
            this.label7.TabIndex = 38;
            this.label7.Text = "Name";
            // 
            // NameDel
            // 
            this.NameDel.BackColor = System.Drawing.Color.Silver;
            this.NameDel.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameDel.Location = new System.Drawing.Point(868, 261);
            this.NameDel.Name = "NameDel";
            this.NameDel.Size = new System.Drawing.Size(344, 44);
            this.NameDel.TabIndex = 37;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(374, 198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(178, 36);
            this.label8.TabIndex = 36;
            this.label8.Text = "Surname";
            // 
            // SurnameDel
            // 
            this.SurnameDel.BackColor = System.Drawing.Color.Silver;
            this.SurnameDel.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SurnameDel.Location = new System.Drawing.Point(868, 190);
            this.SurnameDel.Name = "SurnameDel";
            this.SurnameDel.Size = new System.Drawing.Size(344, 44);
            this.SurnameDel.TabIndex = 35;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.OliveDrab;
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Location = new System.Drawing.Point(4, 89);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1389, 686);
            this.tabPage2.TabIndex = 9;
            this.tabPage2.Text = "Exit";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(486, 304);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(668, 134);
            this.button1.TabIndex = 23;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1397, 779);
            this.Controls.Add(this.AddR);
            this.Font = new System.Drawing.Font("Modern No. 20", 7.8F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Admin_Load);
            this.AddR.ResumeLayout(false);
            this.RoomInfo.ResumeLayout(false);
            this.RoomInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
            this.AddCatT.ResumeLayout(false);
            this.AddCatT.PerformLayout();
            this.ViewServi.ResumeLayout(false);
            this.ViewServi.PerformLayout();
            this.AService.ResumeLayout(false);
            this.AService.PerformLayout();
            this.AddE.ResumeLayout(false);
            this.AddE.PerformLayout();
            this.MyOrder.ResumeLayout(false);
            this.MyOrder.PerformLayout();
            this.Request.ResumeLayout(false);
            this.Request.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Data.OleDb.OleDbConnection cn;
        private System.Windows.Forms.TabControl AddR;
        private System.Windows.Forms.TabPage RoomInfo;
        private System.Windows.Forms.Button ShowCat;
        private System.Windows.Forms.Label CategName;
        private System.Windows.Forms.ComboBox table;
        private System.Windows.Forms.TabPage AddCatT;
        private System.Windows.Forms.Button AddCateg;
        private System.Windows.Forms.TextBox CostNight;
        private System.Windows.Forms.Label CostperNight;
        private System.Windows.Forms.TextBox RoomCap;
        private System.Windows.Forms.Label RoomL;
        private System.Windows.Forms.TabPage ViewServi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CatId;
        private System.Windows.Forms.Label Label;
        private System.Windows.Forms.TextBox RoomIdAdd;
        private System.Windows.Forms.Button AddRoom;
        private System.Windows.Forms.TabPage AService;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ServName;
        private System.Windows.Forms.Label ResId;
        private System.Windows.Forms.TextBox CostSer;
        private System.Windows.Forms.Button AddServ;
        private System.Windows.Forms.TabPage AddE;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button AddEmpl;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox NameE;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Surname;
        private System.Windows.Forms.TabPage MyOrder;
        private System.Windows.Forms.DataGrid dg;
        private System.Windows.Forms.TextBox NumberRooms;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox Bathroom;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox TV;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox CatName;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox DE;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox ME;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox YE;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox DB;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox MB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox YearB;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox status;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox description;
        private System.Windows.Forms.Button AddStatus;
        private System.Windows.Forms.TabPage Request;
        private System.Windows.Forms.Button ShowRequests;
        private System.Windows.Forms.ComboBox SelectStatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox SelectEmpl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.ComboBox SelectId;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox DD;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox MD;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox YD;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox NameDel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox SurnameDel;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button1;
    }
}