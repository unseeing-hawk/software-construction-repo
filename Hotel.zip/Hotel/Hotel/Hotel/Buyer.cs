﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Hotel
{
    public partial class Buyer : Form
    {
        public Buyer()
        {
            InitializeComponent();
            cn.Open();

            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * from [ListOfSuppliers]", cn);
            DataTable tbl = new DataTable();
            da.Fill(tbl);
            supl.DataSource = tbl;
            supl.DisplayMember = "SupplierId";// столбец для отображения
            supl.ValueMember = "SupplierId";//столбец с id


        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "[ListOfSuppliers]";
            OleDbDataAdapter dAdapt = new OleDbDataAdapter("SELECT * FROM [ListOfSuppliers]", cn);
            DataTable table = new DataTable(str);
            if (!dSet.Tables.Contains(str))
            {
                dSet.Tables.Add(table);
                dataGrid1.SetDataBinding(dSet, str);
                dAdapt.Fill(dSet, str);
            }
            dataGrid1.DataMember = str;
        }

        private void ShowCat_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "[ListOfProductsFromSupplier]";
            String sel = "SELECT  ProductId, UnitCost FROM [ListOfProductsFromSupplier] WHERE SupplierId = " 
                + supl.Text;
            OleDbDataAdapter dAdapt = new OleDbDataAdapter(sel, cn);
            DataTable table = new DataTable(str);
            if (!dSet.Tables.Contains(str))
            {
                dSet.Tables.Add(table);
                dg.SetDataBinding(dSet, str);
                dAdapt.Fill(dSet, str);
            }
            dg.DataMember = str;

            
            str = "ProductList";
            dAdapt = new OleDbDataAdapter("SELECT * FROM ProductList", cn);
            table = new DataTable(str);
            if (!dSet.Tables.Contains(str))
            {
                dSet.Tables.Add(table);
                dataGrid2.SetDataBinding(dSet, str);
                dAdapt.Fill(dSet, str);
            }
            dataGrid2.DataMember = str;
        }

        private void Buy_Click(object sender, EventArgs e)
        {
            cn.Open();
            if ((ProductId.TextLength == 0) || (CountOfProducts.TextLength == 0) || (SupplierIdBuy.TextLength == 0))
            {
                MessageBox.Show("Not all data entered!", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                String date = DateTime.Today.Year + "-" + DateTime.Today.Month + "-" + DateTime.Today.Day;
                OleDbCommand commandServ = new OleDbCommand("InsertPurchases", cn);
                commandServ.CommandType = CommandType.StoredProcedure;
                commandServ.Parameters.AddWithValue("@ProductId", ProductId.Text);
                commandServ.Parameters.AddWithValue("@CountOfProducts", CountOfProducts.Text);
                commandServ.Parameters.AddWithValue("@Date", date);
                commandServ.Parameters.AddWithValue("@SupplierId", SupplierIdBuy.Text);
                commandServ.ExecuteReader();
                MessageBox.Show("Purchase generated!", "Successfully", MessageBoxButtons.OK);
            }
            cn.Close();
        }

        private void Buyer_Load(object sender, EventArgs e)
        {
            cn.Close();
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "[PurchasesByTheBuyer]";
            OleDbDataAdapter dAdapt = new OleDbDataAdapter("SELECT * FROM [PurchasesByTheBuyer]", cn);
            DataTable table = new DataTable(str);
            if (!dSet.Tables.Contains(str))
            {
                dSet.Tables.Add(table);
                dataGrid3.SetDataBinding(dSet, str);
                dAdapt.Fill(dSet, str);
            }
            dataGrid3.DataMember = str;
        }

        private void AddStatus_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "UPDATE [PurchasesByTheBuyer] SET StatusId = '" + SelectStat.Text
                + "' WHERE PurchaseId = " + (SelectPurc.SelectedIndex + 1);
            OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSet, "PurchasesByTheBuyer");
            MessageBox.Show("Changes saved!", "Successfully", MessageBoxButtons.OK);
        }

        private void ShowRequests_Click(object sender, EventArgs e)
        {
            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * from Status", cn);
            DataTable tbl = new DataTable();
            da.Fill(tbl);
            SelectStat.DataSource = tbl;
            SelectStat.DisplayMember = "StatusId";// столбец для отображения
            SelectStat.ValueMember = "StatusId";//столбец с id

            OleDbDataAdapter daEmp = new OleDbDataAdapter("SELECT * from PurchasesByTheBuyer", cn);
            DataTable tblEmp = new DataTable();
            daEmp.Fill(tblEmp);
            SelectPurc.DataSource = tblEmp;
            SelectPurc.DisplayMember = "PurchaseId";// столбец для отображения
            SelectPurc.ValueMember = "PurchaseId";//столбец с id
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "[Status]";
            OleDbDataAdapter dAdapt = new OleDbDataAdapter("SELECT * FROM [Status]", cn);
            DataTable table = new DataTable(str);
            if (!dSet.Tables.Contains(str))
            {
                dSet.Tables.Add(table);
                dataGrid4.SetDataBinding(dSet, str);
                dAdapt.Fill(dSet, str);
            }
            dataGrid4.DataMember = str;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            Hide();
            main.ShowDialog();
            Close();
        }
    }
}
