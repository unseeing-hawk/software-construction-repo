﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Threading.Tasks;
using Kursovaya_Polina;
using Kursach;


namespace Hotel
{
    public partial class Guest : Form
    {
        private int iRowID;
        private DataSet dSetP;
        private DataRow dRowP;
        private DataTable dTableP;
        private String ordId;
        private DataTable dataTable;
        private int i;
        private DataSet dataSet;

        public Guest()
        {
            InitializeComponent();
            cn.Open();
            iRowID = 0;
            i = 0;

            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * from AboutCategories", cn);
            DataTable tbl = new DataTable();
            da.Fill(tbl);
            CatName.DataSource = tbl;
            CatName.DisplayMember = "CategoryName";// столбец для отображения
            CatName.ValueMember = "CategoryId";//столбец с id

            OleDbDataAdapter daServ = new OleDbDataAdapter("SELECT * from ServiceCatalog", cn);
            DataTable tblServ = new DataTable();
            daServ.Fill(tblServ);
            ServiceName.DataSource = tblServ;
            ServiceName.DisplayMember = "NameOfService";// столбец для отображения
            ServiceName.ValueMember = "IdService";//столбец с id

            OleDbDataAdapter daProd = new OleDbDataAdapter("SELECT * from ProductList", cn);
            DataTable tblProd = new DataTable();
            daProd.Fill(tblProd);
            ProdList.DataSource = tblProd;
            ProdList.DisplayMember = "ProductName";// столбец для отображения
            ProdList.ValueMember = "ProductId";//столбец с id
        }

        private void Guest_Load(object sender, EventArgs e)
        {
            cn.Close();
           
        }

        private void ShowCat_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "SELECT * FROM AboutCategories";
            OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSet, "AboutCategories");
            DataTable dTable = dSet.Tables["AboutCategories"];

            DataRow dRow;
            dRow = dTable.Rows[CatName.SelectedIndex];
            TV.Text = dRow["ThePresenceOfATV"].ToString();
            Bathroom.Text = dRow["ThePresenceOfABathroom"].ToString();
            NumbOfRooms.Text = dRow["NumberOfRooms"].ToString();
            RoomCapacity.Text = dRow["RoomCapacity"].ToString();
            CostPerNight.Text = dRow["CostPerNight"].ToString();

            str = "SELECT * FROM AboutRoom WHERE CategoryId = " + (CatName.SelectedIndex + 1);
            cn.Open();
            dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSet, "AboutRoom");
            dTable = dSet.Tables["AboutRoom"];
            ListRoom.Items.Clear();
            List<Object> list = new List<Object>();
            for (int i = 0; i < dTable.Rows.Count; i++)
            {
                dRow = dTable.Rows[i];
                list.Add(dRow["IdRoom"].ToString());
            }

            for (int i = 0; i < dTable.Rows.Count; i++)
            {
                ListRoom.Items.Add(list[i]);
            }


            cn.Close();
        }

        private void Booking_Click(object sender, EventArgs e)
        {
            OleDbDataReader reader;

            DataSet dSet = new DataSet();

            String dateArr = monthCalendar1.SelectionStart.Year + "-" + monthCalendar1.SelectionStart.Month +
                "-" + monthCalendar1.SelectionStart.Day;
            String dateDep = +monthCalendar2.SelectionStart.Year + "-" + monthCalendar2.SelectionStart.Month +
               "-" + monthCalendar2.SelectionStart.Day;

            String case_One = "'" + dateArr + "' < ArrivalDate AND '" + dateDep + "' > DateOfDeparture";
            String case_Two = "'" + dateArr + "' > ArrivalDate AND '" + dateDep + "' < DateOfDeparture";
            String case_Three = "'" + dateArr + "' > ArrivalDate AND '" + dateDep + "' > DateOfDeparture AND '"
                + dateArr + "' < DateOfDeparture";
            String case_Four = "'" + dateArr + "' < ArrivalDate AND '" + dateDep + "' < DateOfDeparture AND '"
                + dateDep + "' > ArrivalDate";

            String str = "SELECT * FROM AboutBooking WHERE IdRoom = " + IdRoom.Text + " AND ( ( " + case_One + " ) OR ( " + case_Two
                                                                              + " ) OR ( " + case_Three + " ) OR ( " + case_Four + " ) )";
            cn.Open();
            OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSet, "AboutBooking");
            DataTable dTable = dSet.Tables["AboutBooking"];
            if (dTable.Rows.Count > 0)
            {
                MessageBox.Show("The number for the selected dates is already taken. Try again!",
                    "Error", MessageBoxButtons.OK);
            }
            else
            {
                OleDbCommand commandBook = new OleDbCommand("InsertBooking", cn);
                commandBook.CommandType = CommandType.StoredProcedure;
                commandBook.Parameters.AddWithValue("@IdRoom", IdRoom.Text);
                commandBook.Parameters.AddWithValue("@ArrivalDate", dateArr);
                commandBook.Parameters.AddWithValue("@DateOfDeparture", dateDep);

                str = "SELECT * FROM ClientInfo WHERE Surname = '" + Surname.Text + "' AND Name = '" + NameG.Text
                          + "' AND PhoneNumber = " + Phone.Text;
                dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "ClientInfo");
                dTable = dSet.Tables["ClientInfo"];
                DataRow dRow;

                OleDbCommand commandClient = new OleDbCommand("InsertClient", cn);

                if (dTable.Rows.Count > 0)
                {
                    dRow = dTable.Rows[0];
                    commandBook.Parameters.AddWithValue("@ClientId", dRow["ClientId"]);
                }
                else
                {
                    commandClient.CommandType = CommandType.StoredProcedure;
                    commandClient.Parameters.AddWithValue("@Surname", Surname.Text);
                    commandClient.Parameters.AddWithValue("@Name", NameG.Text);
                    commandClient.Parameters.AddWithValue("@PhoneNumber", Phone.Text);
                    reader = commandClient.ExecuteReader();

                    dAdapter = new OleDbDataAdapter(str, cn);
                    dAdapter.Fill(dSet, "ClientInfo");
                    dTable = dSet.Tables["ClientInfo"];
                    dRow = dTable.Rows[0];
                    commandBook.Parameters.AddWithValue("@ClientId", dRow["ClientId"]);
                }

                reader = commandBook.ExecuteReader();

                MessageBox.Show("Room booked", "Successfully", MessageBoxButtons.OK);

            }



            cn.Close();
        }

        private void CostL_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ShowServ_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "SELECT * FROM ServiceCatalog";
            OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSet, "ServiceCatalog");
            DataTable dTable = dSet.Tables["ServiceCatalog"];

            DataRow dRow;
            dRow = dTable.Rows[ServiceName.SelectedIndex];
            CostB.Text = dRow["Cost"].ToString();
            int i = ServiceName.SelectedIndex + 1;
            ServiceId.Text = i.ToString();

        }

        private void OrderServiceB_Click(object sender, EventArgs e)
        {
            cn.Open();
            OleDbDataReader reader;
            String date = monthCalendar3.SelectionStart.Year + "-" + monthCalendar3.SelectionStart.Month +
                "-" + monthCalendar3.SelectionStart.Day;
            OleDbCommand commandReq = new OleDbCommand("insertRequest", cn);
            commandReq.CommandType = CommandType.StoredProcedure;
            commandReq.Parameters.AddWithValue("@Date", date);
            commandReq.Parameters.AddWithValue("@ReservationId", ReservationId.Text);
            commandReq.Parameters.AddWithValue("@IdService", ServId.Text);
            reader = commandReq.ExecuteReader();
            MessageBox.Show("Request generated!", "Successfully", MessageBoxButtons.OK);
            cn.Close();
        }

        private void ShowP_Click(object sender, EventArgs e)
        {
            String str = str = "SELECT * FROM ClientInfo WHERE Surname = '" + PersSur.Text + "' AND Name = '" + PersName.Text
                          + "' AND PhoneNumber = " + PersPhone.Text;

            dSetP = new DataSet();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSetP, "ClientInfo");
            dTableP = dSetP.Tables["ClientInfo"];

            if (dTableP.Rows.Count > 0)
            {
                dRowP = dTableP.Rows[0];

                String clId = dRowP["ClientId"].ToString();

                str = "SELECT * FROM AboutBooking WHERE ClientId = '" + clId + "'";
                dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSetP, "AboutBooking");
                dTableP = dSetP.Tables["AboutBooking"];

                ShowPers();
            }
            else
            {
                MessageBox.Show("Сlient not found", "Error", MessageBoxButtons.OK);
            }

        }

        private void ShowPers()
        {
            dRowP = dTableP.Rows[iRowID];
            ReservId.Text = dRowP["ReservationId"].ToString();
            IdRoomP.Text = dRowP["IdRoom"].ToString();
            ArrDateP.Text = dRowP["ArrivalDate"].ToString();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            if (iRowID < dSetP.Tables["AboutBooking"].Rows.Count - 1)
            {
                iRowID++;
                ShowPers();
            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            if (iRowID > 0)
            {
                iRowID--;
                ShowPers();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "SELECT * FROM ProductList";
            OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSet, "ProductList");
            DataTable dTable = dSet.Tables["ProductList"];

            DataRow dRow;
            dRow = dTable.Rows[ProdList.SelectedIndex];
            UnitPrice.Text = dRow["UnitCost($)"].ToString();
            AvailableQuantity.Text = dRow["QuantityInStock"].ToString();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            cn.Open();

            if (ReservIdProd.TextLength == 0)
            {
                MessageBox.Show("Enter Reservation Id!", "Error", MessageBoxButtons.OK);
            }
            else if (Count.TextLength == 0)
            {
                MessageBox.Show("Enter quantity!", "Error", MessageBoxButtons.OK);
            }
            else if (int.Parse(Count.Text) > int.Parse(AvailableQuantity.Text))
            {
                MessageBox.Show("Enter fewer products!", "Error", MessageBoxButtons.OK);
            }
            else if (int.Parse(Count.Text) != 0)
            {
                String date = DateTime.Today.Year + "-" + DateTime.Today.Month + "-" + DateTime.Today.Day; 
                String str = "SELECT * FROM [Order] WHERE Date = '" + date + "' AND ReservationId = " + ReservIdProd.Text;

                DataSet dSet = new DataSet();
                OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "Order");
                DataTable dTable = dSet.Tables["Order"];

                if (dTable.Rows.Count == 0)
                {
                    OleDbCommand commandNew = new OleDbCommand("InsertNewOrder", cn);
                    commandNew.CommandType = CommandType.StoredProcedure;
                    commandNew.Parameters.AddWithValue("@ReservationId", ReservIdProd.Text);
                    commandNew.Parameters.AddWithValue("@Date", date);
                    commandNew.ExecuteReader();

                    dAdapter = new OleDbDataAdapter(str, cn);
                    dAdapter.Fill(dSet, "Order");
                    dTable = dSet.Tables["Order"];
                }
                

                DataRow dRow = dTable.Rows[0];
                ordId = dRow["OrderId"].ToString();

                OleDbCommand command = new OleDbCommand("InsertOrder", cn);

                int cost = int.Parse(UnitPrice.Text) * int.Parse(Count.Text);

                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@OrderId", ordId);
                command.Parameters.AddWithValue("@ProductId", ProdList.SelectedIndex + 1);
                command.Parameters.AddWithValue("@Count", Count.Text);
                command.Parameters.AddWithValue("@Cost", cost);
                command.ExecuteReader();

                MessageBox.Show("Product added to order! To view the entire order, go to the \"My order\" tab", "Successfully", MessageBoxButtons.OK);
               
                String total = dRow["TotalCost"].ToString();
                cost += int.Parse(total);
                str = "UPDATE [Order] SET TotalCost = " + cost + " WHERE ReservationId = " + ReservIdProd.Text;
                dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "Order");

                str = "SELECT * FROM ProductList WHERE ProductId = " + (ProdList.SelectedIndex + 1);
                dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "ProductList");
                dTable = dSet.Tables["ProductList"];
                dRow = dTable.Rows[0];

                String q = dRow["QuantityInStock"].ToString();
                int quantity = int.Parse(q);
                quantity -= int.Parse(Count.Text);

                str = "UPDATE [ProductList] SET QuantityInStock = " + quantity + " WHERE ProductId = " + (ProdList.SelectedIndex + 1);
                dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "ProductList");

              
            }

            cn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String str  = "SELECT * FROM AboutOrder WHERE OrderId = " + ordId;

            dataSet = new DataSet();

            OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dataSet, "AboutOrder");
            dataTable = dataSet.Tables["AboutOrder"];

            if (dataTable.Rows.Count > 0)
            {
                String tot = "SELECT * FROM [Order] WHERE OrderId = " + ordId;
                DataSet datSet = new DataSet();
                OleDbDataAdapter datAdapter = new OleDbDataAdapter(tot, cn);
                datAdapter.Fill(datSet, "[Order]");
                DataTable datTable = datSet.Tables["[Order]"];
                DataRow datRow = datTable.Rows[0];
                TotalC.Text = datRow["TotalCost"].ToString();

                ShowOrd();
            }
            else
            {
                MessageBox.Show("Order not found", "Error", MessageBoxButtons.OK);
            }
        }

        private void ShowName(int prodId)
        {
            String str = "SELECT * FROM ProductList WHERE ProductId = " + prodId;
            OleDbDataAdapter dA = new OleDbDataAdapter(str, cn);
            DataSet dSet = new DataSet();
            dA.Fill(dSet, "ProductList");
            DataTable tab = dSet.Tables["ProductList"];
            DataRow dRow = tab.Rows[0];

            ProdName.Text = dRow["ProductName"].ToString();
        }

        private void ShowOrd()
        {
            DataRow dRow = dataTable.Rows[i];

            String prId = dRow["ProductId"].ToString();
            ShowName(int.Parse(prId));
            ProdCount.Text = dRow["Count"].ToString();
            ProdPrice.Text = dRow["Cost"].ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (i < dataSet.Tables["AboutOrder"].Rows.Count - 1)
            {
                i++;
                ShowOrd();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (i > 0)
            {
                i--;
                ShowOrd();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            Hide();
            main.ShowDialog();
            Close();
        }

        private void Med_Click(object sender, EventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MainFormN mainFormN = new MainFormN();
            mainFormN.ShowDialog();
        }
    }
}
