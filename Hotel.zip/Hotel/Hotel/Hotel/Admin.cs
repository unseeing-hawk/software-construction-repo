﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Threading.Tasks;

namespace Hotel
{
    public partial class Admin : Form
    {
        private OleDbDataAdapter dAdapt;
        private DataSet dSet;

        public Admin()
        {
            InitializeComponent();
            cn.Open();
        }

        private void ShowCat_Click(object sender, EventArgs e)
        {
            if (table.SelectedIndex == 0)
            {
                dSet = new DataSet();
                String str = "AboutBooking";
                dAdapt = new OleDbDataAdapter("SELECT * FROM AboutBooking", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 1)
            {
                dSet = new DataSet();
                String str = "ClientInfo";
                dAdapt = new OleDbDataAdapter("SELECT * FROM ClientInfo", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 2)
            {
                dSet = new DataSet();
                String str = "AboutRoom";
                dAdapt = new OleDbDataAdapter("SELECT * FROM AboutRoom", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 3)
            {
                dSet = new DataSet();
                String str = "AboutCategories";
                dAdapt = new OleDbDataAdapter("SELECT * FROM AboutCategories", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 4)
            {
                dSet = new DataSet();
                String str = "[Order]";
                dAdapt = new OleDbDataAdapter("SELECT * FROM [Order]", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 5)
            {
                dSet = new DataSet();
                String str = "AboutOrder";
                dAdapt = new OleDbDataAdapter("SELECT * FROM AboutOrder", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 6)
            {
                dSet = new DataSet();
                String str = "ServiceCatalog";
                dAdapt = new OleDbDataAdapter("SELECT * FROM ServiceCatalog", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 7)
            {
                dSet = new DataSet();
                String str = "ServiceRequest";
                dAdapt = new OleDbDataAdapter("SELECT * FROM ServiceRequest", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 8)
            {
                dSet = new DataSet();
                String str = "ProductList";
                dAdapt = new OleDbDataAdapter("SELECT * FROM ProductList", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 9)
            {
                dSet = new DataSet();
                String str = "Status";
                dAdapt = new OleDbDataAdapter("SELECT * FROM Status", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
            else if (table.SelectedIndex == 10)
            {
                dSet = new DataSet();
                String str = "ListOfEmployees";
                dAdapt = new OleDbDataAdapter("SELECT * FROM ListOfEmployees", cn);
                DataTable table = new DataTable(str);
                if (!dSet.Tables.Contains(str))
                {
                    dSet.Tables.Add(table);
                    dg.SetDataBinding(dSet, str);
                    dAdapt.Fill(dSet, str);
                }
                dg.DataMember = str;
            }
        }

        private void AddCateg_Click(object sender, EventArgs e)
        {
            cn.Open();
            if ((CatName.TextLength == 0) || (TV.TextLength == 0) || (Bathroom.TextLength == 0) || (NumberRooms.TextLength == 0)
                || (RoomCap.TextLength == 0) || (CostNight.TextLength == 0))
            {
                MessageBox.Show("Not all data entered!", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                OleDbCommand commandCat = new OleDbCommand("InsertCat", cn);
                commandCat.CommandType = CommandType.StoredProcedure;
                commandCat.Parameters.AddWithValue("@CategoryName", CatName.Text);
                commandCat.Parameters.AddWithValue("@ThePresenceOfATV", TV.Text);
                commandCat.Parameters.AddWithValue("@ThePresenceOfABathroom", Bathroom.Text);
                commandCat.Parameters.AddWithValue("@NumberOfRooms", NumberRooms.Text);
                commandCat.Parameters.AddWithValue("@RoomCapacity", RoomCap.Text);
                commandCat.Parameters.AddWithValue("@CostPerNight", CostNight.Text);

                commandCat.ExecuteReader();
                MessageBox.Show("Category added!", "Successfully", MessageBoxButtons.OK);
            }
            cn.Close();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            cn.Close();
          
        }

        private void AddRoom_Click(object sender, EventArgs e)
        {
            cn.Open();
            if ((RoomIdAdd.TextLength == 0) || (CatId.TextLength == 0))
            {
                MessageBox.Show("Not all data entered!", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                DataSet dSet = new DataSet();
                String str = "SELECT * FROM AboutRoom WHERE IdRoom = " + RoomIdAdd.Text;
                OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "AboutRoom");
                DataTable dTable = dSet.Tables["AboutRoom"];
                if (dTable.Rows.Count > 0)
                {
                    MessageBox.Show("A number with this id already exists. Try again!",
                        "Error", MessageBoxButtons.OK);
                }
                else
                {
                    OleDbCommand commandRoom = new OleDbCommand("InsertRoom", cn);
                    commandRoom.CommandType = CommandType.StoredProcedure;
                    commandRoom.Parameters.AddWithValue("@IdRoom", RoomIdAdd.Text);
                    commandRoom.Parameters.AddWithValue("@CategoryId", CatId.Text);
                    commandRoom.ExecuteReader();
                    MessageBox.Show("Room added!", "Successfully", MessageBoxButtons.OK);
                }
            }
            cn.Close();
        }

        private void AddServ_Click(object sender, EventArgs e)
        {
            cn.Open();
            if ((ServName.TextLength == 0) || (CostSer.TextLength == 0))
            {
                MessageBox.Show("Not all data entered!", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                DataSet dSet = new DataSet();
                String str = "SELECT * FROM ServiceCatalog WHERE NameOfService = '" + ServName.Text + "'";
                OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "ServiceCatalog");
                DataTable dTable = dSet.Tables["ServiceCatalog"];
                if (dTable.Rows.Count > 0)
                {
                    MessageBox.Show("A service with this name already exists. Try again!",
                        "Error", MessageBoxButtons.OK);
                }
                else
                {
                    OleDbCommand commandServ = new OleDbCommand("InsertServ", cn);
                    commandServ.CommandType = CommandType.StoredProcedure;
                    commandServ.Parameters.AddWithValue("@NameOfService", ServName.Text);
                    commandServ.Parameters.AddWithValue("@Cost", CostSer.Text);
                    commandServ.ExecuteReader();
                    MessageBox.Show("Service added!", "Successfully", MessageBoxButtons.OK);
                }
            }
            cn.Close();
        }

        private void AddEmpl_Click_1(object sender, EventArgs e)
        {
            cn.Open();
            if ((Surname.TextLength == 0) || (NameE.TextLength == 0) || (YearB.TextLength == 0) || (MB.TextLength == 0)
                || (DB.TextLength == 0) || (YE.TextLength == 0) || (ME.TextLength == 0) || (DE.TextLength == 0))
            {
                MessageBox.Show("Not all data entered!", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                String DateB = YearB.Text + "-" + MB.Text + "-" + DB.Text;
                String DateE = YE.Text + "-" + ME.Text + "-" + DE.Text;

                DataSet dSet = new DataSet();
                String str = "SELECT * FROM ListOfEmployees WHERE Surname = '" + Surname.Text + "' AND Name = '"
                    + NameE.Text + "' AND DateOfBirth = '" + DateB + "'";
                OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "ListOfEmployees");
                DataTable dTable = dSet.Tables["ListOfEmployees"];
                if (dTable.Rows.Count > 0)
                {
                    MessageBox.Show("This employee has already been added. Try again!",
                        "Error", MessageBoxButtons.OK);
                }
                else
                {
                    OleDbCommand commandEmpl = new OleDbCommand("InsertEmpl", cn);
                    commandEmpl.CommandType = CommandType.StoredProcedure;
                    commandEmpl.Parameters.AddWithValue("@Surname", Surname.Text);
                    commandEmpl.Parameters.AddWithValue("@Name", NameE.Text);
                    commandEmpl.Parameters.AddWithValue("@DateOfBirth", DateB);
                    commandEmpl.Parameters.AddWithValue("@DateOfEmployment", DateE);
                    commandEmpl.ExecuteReader();
                    MessageBox.Show("Employee added!", "Successfully", MessageBoxButtons.OK);
                }
            }
            cn.Close();
        }

        private void AddStatus_Click(object sender, EventArgs e)
        {
            cn.Open();
            if ((status.TextLength == 0) || (description.TextLength == 0))
            {
                MessageBox.Show("Not all data entered!", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                DataSet dSet = new DataSet();
                String str = "SELECT * FROM Status WHERE StatusId = '" + status.Text + "'";
                OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "Status");
                DataTable dTable = dSet.Tables["Status"];
                if (dTable.Rows.Count > 0)
                {
                    MessageBox.Show("This status has already been added. Try again!",
                        "Error", MessageBoxButtons.OK);
                }
                else
                {
                    OleDbCommand commandStat = new OleDbCommand("InsertStatus", cn);
                    commandStat.CommandType = CommandType.StoredProcedure;
                    commandStat.Parameters.AddWithValue("@StatusId", status.Text);
                    commandStat.Parameters.AddWithValue("@Descryption", description.Text);
                    commandStat.ExecuteReader();
                    MessageBox.Show("Status added!", "Successfully", MessageBoxButtons.OK);
                }
            }
            cn.Close();
        }

      

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void ShowRequests_Click(object sender, EventArgs e)
        {
            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * from ServiceRequest", cn);
            DataTable tbl = new DataTable();
            da.Fill(tbl);
            SelectId.DataSource = tbl;
            SelectId.DisplayMember = "IdRequest";// столбец для отображения
            SelectId.ValueMember = "IdRequest";//столбец с id

            OleDbDataAdapter daEmp = new OleDbDataAdapter("SELECT * from ListOfEmployees", cn);
            DataTable tblEmp = new DataTable();
            daEmp.Fill(tblEmp);
            SelectEmpl.DataSource = tblEmp;
            SelectEmpl.DisplayMember = "EmployeeId";// столбец для отображения
            SelectEmpl.ValueMember = "EmployeeId";//столбец с id

            OleDbDataAdapter daSt = new OleDbDataAdapter("SELECT * from Status", cn);
            DataTable tblSt = new DataTable();
            daSt.Fill(tblSt);
            SelectStatus.DataSource = tblSt;
            SelectStatus.DisplayMember = "StatusId";// столбец для отображения
            SelectStatus.ValueMember = "StatusId";//столбец с id

        }

        private void save_Click(object sender, EventArgs e)
        {
            DataSet dSet = new DataSet();
            String str = "UPDATE [ServiceRequest] SET EmployeeId = " + SelectEmpl.Text
                + " WHERE IdRequest = " + (SelectId.SelectedIndex + 1);
            OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSet, "ServiceRequest");
           
            
            str = "UPDATE [ServiceRequest] SET StatusId = '" + SelectStatus.Text
                + "' WHERE IdRequest = " + (SelectId.SelectedIndex + 1);
            dAdapter = new OleDbDataAdapter(str, cn);
            dAdapter.Fill(dSet, "ServiceRequest");
            MessageBox.Show("Changes saved!", "Successfully", MessageBoxButtons.OK);
        }

        private void Remove_Click(object sender, EventArgs e)
        {
            cn.Open();
            if ((SurnameDel.TextLength == 0) || (NameDel.TextLength == 0) || (YD.TextLength == 0) 
                || (MD.TextLength == 0) || (DD.TextLength == 0) )
            {
                MessageBox.Show("Not all data entered!", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                String DateB = YD.Text + "-" + MD.Text + "-" + DD.Text;

                DataSet dSet = new DataSet();
                String str = "SELECT * FROM ListOfEmployees WHERE Surname = '" + SurnameDel.Text + "' AND Name = '"
                    + NameDel.Text + "' AND DateOfBirth = '" + DateB + "'";

            

                OleDbDataAdapter dAdapter = new OleDbDataAdapter(str, cn);
                dAdapter.Fill(dSet, "ListOfEmployees");
                DataTable dTable = dSet.Tables["ListOfEmployees"];

                if (dTable.Rows.Count > 0)
                {
                    OleDbCommand commandEmpl = new OleDbCommand("DeleteEmpl", cn);
                    commandEmpl.CommandType = CommandType.StoredProcedure;
                    commandEmpl.Parameters.AddWithValue("@Surname", SurnameDel.Text);
                    commandEmpl.Parameters.AddWithValue("@Name", NameDel.Text);
                    commandEmpl.Parameters.AddWithValue("@DateOfBirth", DateB);
                    commandEmpl.ExecuteReader();

                    MessageBox.Show("Employee removed!", "Successfully", MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show("Employee not found. Try again!", "Error", MessageBoxButtons.OK);
                }
            }
            cn.Close();
        }

        private void RoomIdAdd_TextChanged(object sender, EventArgs e)
        {

        }

        private void CatId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Label_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            Hide();
            main.ShowDialog();
            Close();
        }
    }
}
