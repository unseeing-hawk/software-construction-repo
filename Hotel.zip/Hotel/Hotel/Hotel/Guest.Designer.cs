﻿
namespace Hotel
{
    partial class Guest
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Guest));
            this.ViewServices = new System.Windows.Forms.TabControl();
            this.RoomInfo = new System.Windows.Forms.TabPage();
            this.ListRoom = new System.Windows.Forms.ListBox();
            this.ShowCat = new System.Windows.Forms.Button();
            this.IdRo = new System.Windows.Forms.Label();
            this.Cost = new System.Windows.Forms.Label();
            this.CostPerNight = new System.Windows.Forms.TextBox();
            this.Capacity = new System.Windows.Forms.Label();
            this.RoomCapacity = new System.Windows.Forms.TextBox();
            this.NumberOfRooms = new System.Windows.Forms.Label();
            this.NumbOfRooms = new System.Windows.Forms.TextBox();
            this.ThePresenceOfABathroom = new System.Windows.Forms.Label();
            this.Bathroom = new System.Windows.Forms.TextBox();
            this.ThePresenceOfATV = new System.Windows.Forms.Label();
            this.CategName = new System.Windows.Forms.Label();
            this.CatName = new System.Windows.Forms.ComboBox();
            this.TV = new System.Windows.Forms.TextBox();
            this.BookRoom = new System.Windows.Forms.TabPage();
            this.Booking = new System.Windows.Forms.Button();
            this.Phone = new System.Windows.Forms.TextBox();
            this.PhoneL = new System.Windows.Forms.Label();
            this.NameG = new System.Windows.Forms.TextBox();
            this.NameL = new System.Windows.Forms.Label();
            this.Surname = new System.Windows.Forms.TextBox();
            this.SurnameL = new System.Windows.Forms.Label();
            this.monthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.DateOfDeparture = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.ArrivalDate = new System.Windows.Forms.Label();
            this.IdRoom = new System.Windows.Forms.TextBox();
            this.IdRoomL = new System.Windows.Forms.Label();
            this.ViewServi = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.ServiceId = new System.Windows.Forms.TextBox();
            this.CostL = new System.Windows.Forms.Label();
            this.CostB = new System.Windows.Forms.TextBox();
            this.ShowServ = new System.Windows.Forms.Button();
            this.ServiceNameL = new System.Windows.Forms.Label();
            this.ServiceName = new System.Windows.Forms.ComboBox();
            this.OrderService = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.ServId = new System.Windows.Forms.TextBox();
            this.ResId = new System.Windows.Forms.Label();
            this.ReservationId = new System.Windows.Forms.TextBox();
            this.monthCalendar3 = new System.Windows.Forms.MonthCalendar();
            this.label2 = new System.Windows.Forms.Label();
            this.OrderServiceB = new System.Windows.Forms.Button();
            this.BuyProducts = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.ReservIdProd = new System.Windows.Forms.TextBox();
            this.Add = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.Count = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.AvailableQuantity = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.UnitPrice = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.ProdList = new System.Windows.Forms.ComboBox();
            this.MyOrder = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.TotalC = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.ProdPrice = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ProdCount = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.ProdName = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.PersonalArea = new System.Windows.Forms.TabPage();
            this.Next = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.ShowP = new System.Windows.Forms.Button();
            this.ArrDateP = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.IdRoomP = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ReservId = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.PersPhone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PersName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.PersSur = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Med = new System.Windows.Forms.Button();
            this.cn = new System.Data.OleDb.OleDbConnection();
            this.hotelDataSet = new Hotel.HotelDataSet();
            this.Restaurant = new System.Windows.Forms.TabPage();
            this.button6 = new System.Windows.Forms.Button();
            this.ViewServices.SuspendLayout();
            this.RoomInfo.SuspendLayout();
            this.BookRoom.SuspendLayout();
            this.ViewServi.SuspendLayout();
            this.OrderService.SuspendLayout();
            this.BuyProducts.SuspendLayout();
            this.MyOrder.SuspendLayout();
            this.PersonalArea.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet)).BeginInit();
            this.Restaurant.SuspendLayout();
            this.SuspendLayout();
            // 
            // ViewServices
            // 
            this.ViewServices.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.ViewServices.Controls.Add(this.RoomInfo);
            this.ViewServices.Controls.Add(this.BookRoom);
            this.ViewServices.Controls.Add(this.ViewServi);
            this.ViewServices.Controls.Add(this.OrderService);
            this.ViewServices.Controls.Add(this.BuyProducts);
            this.ViewServices.Controls.Add(this.MyOrder);
            this.ViewServices.Controls.Add(this.PersonalArea);
            this.ViewServices.Controls.Add(this.tabPage1);
            this.ViewServices.Controls.Add(this.tabPage2);
            this.ViewServices.Controls.Add(this.Restaurant);
            this.ViewServices.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ViewServices.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewServices.ItemSize = new System.Drawing.Size(400, 41);
            this.ViewServices.Location = new System.Drawing.Point(0, 0);
            this.ViewServices.Multiline = true;
            this.ViewServices.Name = "ViewServices";
            this.ViewServices.SelectedIndex = 0;
            this.ViewServices.Size = new System.Drawing.Size(1397, 779);
            this.ViewServices.TabIndex = 0;
            // 
            // RoomInfo
            // 
            this.RoomInfo.AutoScroll = true;
            this.RoomInfo.BackColor = System.Drawing.Color.OliveDrab;
            this.RoomInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RoomInfo.Controls.Add(this.ListRoom);
            this.RoomInfo.Controls.Add(this.ShowCat);
            this.RoomInfo.Controls.Add(this.IdRo);
            this.RoomInfo.Controls.Add(this.Cost);
            this.RoomInfo.Controls.Add(this.CostPerNight);
            this.RoomInfo.Controls.Add(this.Capacity);
            this.RoomInfo.Controls.Add(this.RoomCapacity);
            this.RoomInfo.Controls.Add(this.NumberOfRooms);
            this.RoomInfo.Controls.Add(this.NumbOfRooms);
            this.RoomInfo.Controls.Add(this.ThePresenceOfABathroom);
            this.RoomInfo.Controls.Add(this.Bathroom);
            this.RoomInfo.Controls.Add(this.ThePresenceOfATV);
            this.RoomInfo.Controls.Add(this.CategName);
            this.RoomInfo.Controls.Add(this.CatName);
            this.RoomInfo.Controls.Add(this.TV);
            this.RoomInfo.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomInfo.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.RoomInfo.ImageKey = "(отсутствует)";
            this.RoomInfo.Location = new System.Drawing.Point(4, 89);
            this.RoomInfo.Name = "RoomInfo";
            this.RoomInfo.Padding = new System.Windows.Forms.Padding(3);
            this.RoomInfo.Size = new System.Drawing.Size(1389, 686);
            this.RoomInfo.TabIndex = 0;
            this.RoomInfo.Text = "Room information";
            // 
            // ListRoom
            // 
            this.ListRoom.BackColor = System.Drawing.Color.Silver;
            this.ListRoom.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListRoom.FormattingEnabled = true;
            this.ListRoom.ItemHeight = 36;
            this.ListRoom.Location = new System.Drawing.Point(976, 561);
            this.ListRoom.Name = "ListRoom";
            this.ListRoom.Size = new System.Drawing.Size(139, 76);
            this.ListRoom.Sorted = true;
            this.ListRoom.TabIndex = 16;
            // 
            // ShowCat
            // 
            this.ShowCat.BackColor = System.Drawing.Color.Silver;
            this.ShowCat.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowCat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShowCat.Location = new System.Drawing.Point(1149, 154);
            this.ShowCat.Name = "ShowCat";
            this.ShowCat.Size = new System.Drawing.Size(148, 43);
            this.ShowCat.TabIndex = 15;
            this.ShowCat.Text = "Show";
            this.ShowCat.UseVisualStyleBackColor = false;
            this.ShowCat.Click += new System.EventHandler(this.ShowCat_Click);
            // 
            // IdRo
            // 
            this.IdRo.AutoSize = true;
            this.IdRo.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdRo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.IdRo.Location = new System.Drawing.Point(347, 561);
            this.IdRo.Name = "IdRo";
            this.IdRo.Size = new System.Drawing.Size(171, 36);
            this.IdRo.TabIndex = 14;
            this.IdRo.Text = "Id Room";
            // 
            // Cost
            // 
            this.Cost.AutoSize = true;
            this.Cost.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cost.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Cost.Location = new System.Drawing.Point(347, 504);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(293, 36);
            this.Cost.TabIndex = 12;
            this.Cost.Text = "Cost per night";
            // 
            // CostPerNight
            // 
            this.CostPerNight.BackColor = System.Drawing.Color.Silver;
            this.CostPerNight.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostPerNight.Location = new System.Drawing.Point(976, 504);
            this.CostPerNight.Name = "CostPerNight";
            this.CostPerNight.ReadOnly = true;
            this.CostPerNight.Size = new System.Drawing.Size(139, 44);
            this.CostPerNight.TabIndex = 11;
            // 
            // Capacity
            // 
            this.Capacity.AutoSize = true;
            this.Capacity.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Capacity.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Capacity.Location = new System.Drawing.Point(347, 444);
            this.Capacity.Name = "Capacity";
            this.Capacity.Size = new System.Drawing.Size(304, 36);
            this.Capacity.TabIndex = 10;
            this.Capacity.Text = "Room capacity";
            // 
            // RoomCapacity
            // 
            this.RoomCapacity.BackColor = System.Drawing.Color.Silver;
            this.RoomCapacity.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomCapacity.Location = new System.Drawing.Point(976, 444);
            this.RoomCapacity.Name = "RoomCapacity";
            this.RoomCapacity.ReadOnly = true;
            this.RoomCapacity.Size = new System.Drawing.Size(139, 44);
            this.RoomCapacity.TabIndex = 9;
            // 
            // NumberOfRooms
            // 
            this.NumberOfRooms.AutoSize = true;
            this.NumberOfRooms.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumberOfRooms.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.NumberOfRooms.Location = new System.Drawing.Point(347, 385);
            this.NumberOfRooms.Name = "NumberOfRooms";
            this.NumberOfRooms.Size = new System.Drawing.Size(346, 36);
            this.NumberOfRooms.TabIndex = 8;
            this.NumberOfRooms.Text = "Number of rooms";
            // 
            // NumbOfRooms
            // 
            this.NumbOfRooms.BackColor = System.Drawing.Color.Silver;
            this.NumbOfRooms.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumbOfRooms.Location = new System.Drawing.Point(976, 385);
            this.NumbOfRooms.Name = "NumbOfRooms";
            this.NumbOfRooms.ReadOnly = true;
            this.NumbOfRooms.Size = new System.Drawing.Size(139, 44);
            this.NumbOfRooms.TabIndex = 7;
            // 
            // ThePresenceOfABathroom
            // 
            this.ThePresenceOfABathroom.AutoSize = true;
            this.ThePresenceOfABathroom.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThePresenceOfABathroom.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ThePresenceOfABathroom.Location = new System.Drawing.Point(347, 322);
            this.ThePresenceOfABathroom.Name = "ThePresenceOfABathroom";
            this.ThePresenceOfABathroom.Size = new System.Drawing.Size(549, 36);
            this.ThePresenceOfABathroom.TabIndex = 6;
            this.ThePresenceOfABathroom.Text = "The presence of a bathroom";
            // 
            // Bathroom
            // 
            this.Bathroom.BackColor = System.Drawing.Color.Silver;
            this.Bathroom.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bathroom.Location = new System.Drawing.Point(976, 322);
            this.Bathroom.Name = "Bathroom";
            this.Bathroom.ReadOnly = true;
            this.Bathroom.Size = new System.Drawing.Size(139, 44);
            this.Bathroom.TabIndex = 5;
            // 
            // ThePresenceOfATV
            // 
            this.ThePresenceOfATV.AutoSize = true;
            this.ThePresenceOfATV.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThePresenceOfATV.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ThePresenceOfATV.Location = new System.Drawing.Point(347, 265);
            this.ThePresenceOfATV.Name = "ThePresenceOfATV";
            this.ThePresenceOfATV.Size = new System.Drawing.Size(395, 36);
            this.ThePresenceOfATV.TabIndex = 4;
            this.ThePresenceOfATV.Text = "The presence of a TV";
            // 
            // CategName
            // 
            this.CategName.AutoSize = true;
            this.CategName.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CategName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.CategName.Location = new System.Drawing.Point(247, 156);
            this.CategName.Name = "CategName";
            this.CategName.Size = new System.Drawing.Size(343, 40);
            this.CategName.TabIndex = 3;
            this.CategName.Text = "Category name";
            // 
            // CatName
            // 
            this.CatName.BackColor = System.Drawing.Color.Silver;
            this.CatName.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.CatName.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatName.FormattingEnabled = true;
            this.CatName.Location = new System.Drawing.Point(620, 153);
            this.CatName.Name = "CatName";
            this.CatName.Size = new System.Drawing.Size(457, 48);
            this.CatName.TabIndex = 2;
            // 
            // TV
            // 
            this.TV.BackColor = System.Drawing.Color.Silver;
            this.TV.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TV.Location = new System.Drawing.Point(976, 265);
            this.TV.Name = "TV";
            this.TV.ReadOnly = true;
            this.TV.Size = new System.Drawing.Size(139, 44);
            this.TV.TabIndex = 1;
            // 
            // BookRoom
            // 
            this.BookRoom.BackColor = System.Drawing.Color.OliveDrab;
            this.BookRoom.Controls.Add(this.Booking);
            this.BookRoom.Controls.Add(this.Phone);
            this.BookRoom.Controls.Add(this.PhoneL);
            this.BookRoom.Controls.Add(this.NameG);
            this.BookRoom.Controls.Add(this.NameL);
            this.BookRoom.Controls.Add(this.Surname);
            this.BookRoom.Controls.Add(this.SurnameL);
            this.BookRoom.Controls.Add(this.monthCalendar2);
            this.BookRoom.Controls.Add(this.DateOfDeparture);
            this.BookRoom.Controls.Add(this.monthCalendar1);
            this.BookRoom.Controls.Add(this.ArrivalDate);
            this.BookRoom.Controls.Add(this.IdRoom);
            this.BookRoom.Controls.Add(this.IdRoomL);
            this.BookRoom.ForeColor = System.Drawing.Color.Ivory;
            this.BookRoom.Location = new System.Drawing.Point(4, 89);
            this.BookRoom.Name = "BookRoom";
            this.BookRoom.Padding = new System.Windows.Forms.Padding(3);
            this.BookRoom.Size = new System.Drawing.Size(1389, 686);
            this.BookRoom.TabIndex = 1;
            this.BookRoom.Text = "Book a room";
            // 
            // Booking
            // 
            this.Booking.BackColor = System.Drawing.Color.Silver;
            this.Booking.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Booking.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Booking.Location = new System.Drawing.Point(533, 653);
            this.Booking.Name = "Booking";
            this.Booking.Size = new System.Drawing.Size(420, 49);
            this.Booking.TabIndex = 16;
            this.Booking.Text = "Make a reservation";
            this.Booking.UseVisualStyleBackColor = false;
            this.Booking.Click += new System.EventHandler(this.Booking_Click);
            // 
            // Phone
            // 
            this.Phone.BackColor = System.Drawing.Color.Silver;
            this.Phone.Location = new System.Drawing.Point(856, 548);
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(272, 40);
            this.Phone.TabIndex = 13;
            // 
            // PhoneL
            // 
            this.PhoneL.AutoSize = true;
            this.PhoneL.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneL.Location = new System.Drawing.Point(476, 548);
            this.PhoneL.Name = "PhoneL";
            this.PhoneL.Size = new System.Drawing.Size(123, 34);
            this.PhoneL.TabIndex = 12;
            this.PhoneL.Text = "Phone";
            // 
            // NameG
            // 
            this.NameG.BackColor = System.Drawing.Color.Silver;
            this.NameG.Location = new System.Drawing.Point(856, 489);
            this.NameG.Name = "NameG";
            this.NameG.Size = new System.Drawing.Size(272, 40);
            this.NameG.TabIndex = 11;
            // 
            // NameL
            // 
            this.NameL.AutoSize = true;
            this.NameL.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameL.Location = new System.Drawing.Point(476, 495);
            this.NameL.Name = "NameL";
            this.NameL.Size = new System.Drawing.Size(108, 34);
            this.NameL.TabIndex = 10;
            this.NameL.Text = "Name";
            // 
            // Surname
            // 
            this.Surname.BackColor = System.Drawing.Color.Silver;
            this.Surname.Location = new System.Drawing.Point(856, 431);
            this.Surname.Name = "Surname";
            this.Surname.Size = new System.Drawing.Size(272, 40);
            this.Surname.TabIndex = 9;
            // 
            // SurnameL
            // 
            this.SurnameL.AutoSize = true;
            this.SurnameL.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SurnameL.Location = new System.Drawing.Point(476, 437);
            this.SurnameL.Name = "SurnameL";
            this.SurnameL.Size = new System.Drawing.Size(167, 34);
            this.SurnameL.TabIndex = 8;
            this.SurnameL.Text = "Surname";
            // 
            // monthCalendar2
            // 
            this.monthCalendar2.BackColor = System.Drawing.Color.Silver;
            this.monthCalendar2.CalendarDimensions = new System.Drawing.Size(2, 1);
            this.monthCalendar2.Location = new System.Drawing.Point(857, 109);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.TabIndex = 5;
            this.monthCalendar2.TitleBackColor = System.Drawing.Color.Silver;
            this.monthCalendar2.TitleForeColor = System.Drawing.Color.Black;
            this.monthCalendar2.TrailingForeColor = System.Drawing.Color.Silver;
            // 
            // DateOfDeparture
            // 
            this.DateOfDeparture.AutoSize = true;
            this.DateOfDeparture.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateOfDeparture.Location = new System.Drawing.Point(882, 64);
            this.DateOfDeparture.Name = "DateOfDeparture";
            this.DateOfDeparture.Size = new System.Drawing.Size(343, 34);
            this.DateOfDeparture.TabIndex = 4;
            this.DateOfDeparture.Text = "Date of departure";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.BackColor = System.Drawing.Color.Silver;
            this.monthCalendar1.CalendarDimensions = new System.Drawing.Size(2, 1);
            this.monthCalendar1.Location = new System.Drawing.Point(326, 109);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 3;
            this.monthCalendar1.TitleBackColor = System.Drawing.Color.Silver;
            this.monthCalendar1.TitleForeColor = System.Drawing.Color.Black;
            this.monthCalendar1.TrailingForeColor = System.Drawing.Color.Silver;
            // 
            // ArrivalDate
            // 
            this.ArrivalDate.AutoSize = true;
            this.ArrivalDate.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ArrivalDate.Location = new System.Drawing.Point(378, 64);
            this.ArrivalDate.Name = "ArrivalDate";
            this.ArrivalDate.Size = new System.Drawing.Size(250, 34);
            this.ArrivalDate.TabIndex = 2;
            this.ArrivalDate.Text = "Arrival date";
            // 
            // IdRoom
            // 
            this.IdRoom.BackColor = System.Drawing.Color.Silver;
            this.IdRoom.Location = new System.Drawing.Point(856, 366);
            this.IdRoom.Name = "IdRoom";
            this.IdRoom.Size = new System.Drawing.Size(272, 40);
            this.IdRoom.TabIndex = 1;
            // 
            // IdRoomL
            // 
            this.IdRoomL.AutoSize = true;
            this.IdRoomL.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdRoomL.Location = new System.Drawing.Point(476, 372);
            this.IdRoomL.Name = "IdRoomL";
            this.IdRoomL.Size = new System.Drawing.Size(159, 34);
            this.IdRoomL.TabIndex = 0;
            this.IdRoomL.Text = "Id Room";
            // 
            // ViewServi
            // 
            this.ViewServi.BackColor = System.Drawing.Color.OliveDrab;
            this.ViewServi.Controls.Add(this.label1);
            this.ViewServi.Controls.Add(this.ServiceId);
            this.ViewServi.Controls.Add(this.CostL);
            this.ViewServi.Controls.Add(this.CostB);
            this.ViewServi.Controls.Add(this.ShowServ);
            this.ViewServi.Controls.Add(this.ServiceNameL);
            this.ViewServi.Controls.Add(this.ServiceName);
            this.ViewServi.Location = new System.Drawing.Point(4, 89);
            this.ViewServi.Name = "ViewServi";
            this.ViewServi.Padding = new System.Windows.Forms.Padding(3);
            this.ViewServi.Size = new System.Drawing.Size(1389, 686);
            this.ViewServi.TabIndex = 4;
            this.ViewServi.Text = "View services";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(168, 436);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 36);
            this.label1.TabIndex = 27;
            this.label1.Text = "Service Id";
            // 
            // ServiceId
            // 
            this.ServiceId.BackColor = System.Drawing.Color.Silver;
            this.ServiceId.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceId.Location = new System.Drawing.Point(592, 428);
            this.ServiceId.Name = "ServiceId";
            this.ServiceId.ReadOnly = true;
            this.ServiceId.Size = new System.Drawing.Size(344, 44);
            this.ServiceId.TabIndex = 26;
            // 
            // CostL
            // 
            this.CostL.AutoSize = true;
            this.CostL.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostL.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.CostL.Location = new System.Drawing.Point(168, 349);
            this.CostL.Name = "CostL";
            this.CostL.Size = new System.Drawing.Size(100, 36);
            this.CostL.TabIndex = 25;
            this.CostL.Text = "Cost";
            // 
            // CostB
            // 
            this.CostB.BackColor = System.Drawing.Color.Silver;
            this.CostB.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CostB.Location = new System.Drawing.Point(592, 341);
            this.CostB.Name = "CostB";
            this.CostB.ReadOnly = true;
            this.CostB.Size = new System.Drawing.Size(344, 44);
            this.CostB.TabIndex = 24;
            // 
            // ShowServ
            // 
            this.ShowServ.BackColor = System.Drawing.Color.Silver;
            this.ShowServ.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowServ.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShowServ.Location = new System.Drawing.Point(1090, 226);
            this.ShowServ.Name = "ShowServ";
            this.ShowServ.Size = new System.Drawing.Size(148, 43);
            this.ShowServ.TabIndex = 23;
            this.ShowServ.Text = "Show";
            this.ShowServ.UseVisualStyleBackColor = false;
            this.ShowServ.Click += new System.EventHandler(this.ShowServ_Click);
            // 
            // ServiceNameL
            // 
            this.ServiceNameL.AutoSize = true;
            this.ServiceNameL.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceNameL.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ServiceNameL.Location = new System.Drawing.Point(167, 227);
            this.ServiceNameL.Name = "ServiceNameL";
            this.ServiceNameL.Size = new System.Drawing.Size(284, 40);
            this.ServiceNameL.TabIndex = 22;
            this.ServiceNameL.Text = "Service name";
            // 
            // ServiceName
            // 
            this.ServiceName.BackColor = System.Drawing.Color.Silver;
            this.ServiceName.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ServiceName.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceName.FormattingEnabled = true;
            this.ServiceName.Location = new System.Drawing.Point(592, 223);
            this.ServiceName.Name = "ServiceName";
            this.ServiceName.Size = new System.Drawing.Size(457, 48);
            this.ServiceName.TabIndex = 21;
            // 
            // OrderService
            // 
            this.OrderService.BackColor = System.Drawing.Color.OliveDrab;
            this.OrderService.Controls.Add(this.label3);
            this.OrderService.Controls.Add(this.ServId);
            this.OrderService.Controls.Add(this.ResId);
            this.OrderService.Controls.Add(this.ReservationId);
            this.OrderService.Controls.Add(this.monthCalendar3);
            this.OrderService.Controls.Add(this.label2);
            this.OrderService.Controls.Add(this.OrderServiceB);
            this.OrderService.Location = new System.Drawing.Point(4, 89);
            this.OrderService.Name = "OrderService";
            this.OrderService.Padding = new System.Windows.Forms.Padding(3);
            this.OrderService.Size = new System.Drawing.Size(1389, 686);
            this.OrderService.TabIndex = 2;
            this.OrderService.Text = "Order service";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(110, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 36);
            this.label3.TabIndex = 27;
            this.label3.Text = "Service Id";
            // 
            // ServId
            // 
            this.ServId.BackColor = System.Drawing.Color.Silver;
            this.ServId.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServId.Location = new System.Drawing.Point(534, 162);
            this.ServId.Name = "ServId";
            this.ServId.Size = new System.Drawing.Size(344, 44);
            this.ServId.TabIndex = 26;
            // 
            // ResId
            // 
            this.ResId.AutoSize = true;
            this.ResId.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResId.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.ResId.Location = new System.Drawing.Point(110, 270);
            this.ResId.Name = "ResId";
            this.ResId.Size = new System.Drawing.Size(293, 36);
            this.ResId.TabIndex = 25;
            this.ResId.Text = "Reservation Id";
            // 
            // ReservationId
            // 
            this.ReservationId.BackColor = System.Drawing.Color.Silver;
            this.ReservationId.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReservationId.Location = new System.Drawing.Point(534, 262);
            this.ReservationId.Name = "ReservationId";
            this.ReservationId.Size = new System.Drawing.Size(344, 44);
            this.ReservationId.TabIndex = 24;
            // 
            // monthCalendar3
            // 
            this.monthCalendar3.BackColor = System.Drawing.Color.Silver;
            this.monthCalendar3.Location = new System.Drawing.Point(536, 370);
            this.monthCalendar3.Name = "monthCalendar3";
            this.monthCalendar3.TabIndex = 23;
            this.monthCalendar3.TitleBackColor = System.Drawing.Color.Silver;
            this.monthCalendar3.TitleForeColor = System.Drawing.Color.Black;
            this.monthCalendar3.TrailingForeColor = System.Drawing.Color.Silver;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(112, 405);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 34);
            this.label2.TabIndex = 22;
            this.label2.Text = "Date";
            // 
            // OrderServiceB
            // 
            this.OrderServiceB.BackColor = System.Drawing.Color.Silver;
            this.OrderServiceB.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderServiceB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.OrderServiceB.Location = new System.Drawing.Point(899, 405);
            this.OrderServiceB.Name = "OrderServiceB";
            this.OrderServiceB.Size = new System.Drawing.Size(330, 104);
            this.OrderServiceB.TabIndex = 21;
            this.OrderServiceB.Text = "Order service";
            this.OrderServiceB.UseVisualStyleBackColor = false;
            this.OrderServiceB.Click += new System.EventHandler(this.OrderServiceB_Click);
            // 
            // BuyProducts
            // 
            this.BuyProducts.BackColor = System.Drawing.Color.OliveDrab;
            this.BuyProducts.Controls.Add(this.label14);
            this.BuyProducts.Controls.Add(this.ReservIdProd);
            this.BuyProducts.Controls.Add(this.Add);
            this.BuyProducts.Controls.Add(this.label13);
            this.BuyProducts.Controls.Add(this.Count);
            this.BuyProducts.Controls.Add(this.label10);
            this.BuyProducts.Controls.Add(this.AvailableQuantity);
            this.BuyProducts.Controls.Add(this.label11);
            this.BuyProducts.Controls.Add(this.UnitPrice);
            this.BuyProducts.Controls.Add(this.button1);
            this.BuyProducts.Controls.Add(this.label12);
            this.BuyProducts.Controls.Add(this.ProdList);
            this.BuyProducts.Location = new System.Drawing.Point(4, 89);
            this.BuyProducts.Name = "BuyProducts";
            this.BuyProducts.Padding = new System.Windows.Forms.Padding(3);
            this.BuyProducts.Size = new System.Drawing.Size(1389, 686);
            this.BuyProducts.TabIndex = 3;
            this.BuyProducts.Text = "List of products";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(229, 464);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(410, 36);
            this.label14.TabIndex = 39;
            this.label14.Text = "Enter Reservation Id";
            // 
            // ReservIdProd
            // 
            this.ReservIdProd.BackColor = System.Drawing.Color.Silver;
            this.ReservIdProd.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReservIdProd.Location = new System.Drawing.Point(653, 456);
            this.ReservIdProd.Name = "ReservIdProd";
            this.ReservIdProd.Size = new System.Drawing.Size(344, 44);
            this.ReservIdProd.TabIndex = 38;
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.Color.Silver;
            this.Add.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Add.Location = new System.Drawing.Point(1098, 512);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(148, 43);
            this.Add.TabIndex = 37;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(229, 521);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(316, 36);
            this.label13.TabIndex = 36;
            this.label13.Text = "Enter quantity";
            // 
            // Count
            // 
            this.Count.BackColor = System.Drawing.Color.Silver;
            this.Count.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Count.Location = new System.Drawing.Point(653, 513);
            this.Count.Name = "Count";
            this.Count.Size = new System.Drawing.Size(344, 44);
            this.Count.TabIndex = 35;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(229, 347);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(393, 36);
            this.label10.TabIndex = 34;
            this.label10.Text = "Available quantity";
            // 
            // AvailableQuantity
            // 
            this.AvailableQuantity.BackColor = System.Drawing.Color.Silver;
            this.AvailableQuantity.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvailableQuantity.Location = new System.Drawing.Point(653, 339);
            this.AvailableQuantity.Name = "AvailableQuantity";
            this.AvailableQuantity.ReadOnly = true;
            this.AvailableQuantity.Size = new System.Drawing.Size(344, 44);
            this.AvailableQuantity.TabIndex = 33;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(229, 260);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(235, 36);
            this.label11.TabIndex = 32;
            this.label11.Text = "Unit price($)";
            // 
            // UnitPrice
            // 
            this.UnitPrice.BackColor = System.Drawing.Color.Silver;
            this.UnitPrice.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnitPrice.Location = new System.Drawing.Point(653, 252);
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.Size = new System.Drawing.Size(344, 44);
            this.UnitPrice.TabIndex = 31;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(1151, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 43);
            this.button1.TabIndex = 30;
            this.button1.Text = "Show";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(228, 138);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(322, 40);
            this.label12.TabIndex = 29;
            this.label12.Text = "Product name";
            // 
            // ProdList
            // 
            this.ProdList.BackColor = System.Drawing.Color.Silver;
            this.ProdList.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ProdList.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProdList.FormattingEnabled = true;
            this.ProdList.Location = new System.Drawing.Point(653, 134);
            this.ProdList.Name = "ProdList";
            this.ProdList.Size = new System.Drawing.Size(457, 48);
            this.ProdList.TabIndex = 28;
            // 
            // MyOrder
            // 
            this.MyOrder.BackColor = System.Drawing.Color.OliveDrab;
            this.MyOrder.Controls.Add(this.button4);
            this.MyOrder.Controls.Add(this.TotalC);
            this.MyOrder.Controls.Add(this.label18);
            this.MyOrder.Controls.Add(this.button2);
            this.MyOrder.Controls.Add(this.button3);
            this.MyOrder.Controls.Add(this.ProdPrice);
            this.MyOrder.Controls.Add(this.label15);
            this.MyOrder.Controls.Add(this.ProdCount);
            this.MyOrder.Controls.Add(this.label16);
            this.MyOrder.Controls.Add(this.ProdName);
            this.MyOrder.Controls.Add(this.label17);
            this.MyOrder.Location = new System.Drawing.Point(4, 89);
            this.MyOrder.Name = "MyOrder";
            this.MyOrder.Padding = new System.Windows.Forms.Padding(3);
            this.MyOrder.Size = new System.Drawing.Size(1389, 686);
            this.MyOrder.TabIndex = 6;
            this.MyOrder.Text = "My Order";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Silver;
            this.button4.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button4.Location = new System.Drawing.Point(561, 115);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(368, 43);
            this.button4.TabIndex = 39;
            this.button4.Text = "Show";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // TotalC
            // 
            this.TotalC.BackColor = System.Drawing.Color.Silver;
            this.TotalC.Location = new System.Drawing.Point(1025, 523);
            this.TotalC.Name = "TotalC";
            this.TotalC.ReadOnly = true;
            this.TotalC.Size = new System.Drawing.Size(272, 40);
            this.TotalC.TabIndex = 38;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(645, 529);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(209, 34);
            this.label18.TabIndex = 37;
            this.label18.Text = "Total Cost";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Silver;
            this.button2.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(775, 424);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 43);
            this.button2.TabIndex = 36;
            this.button2.Text = "Next";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Silver;
            this.button3.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button3.Location = new System.Drawing.Point(553, 424);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(154, 43);
            this.button3.TabIndex = 35;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // ProdPrice
            // 
            this.ProdPrice.BackColor = System.Drawing.Color.Silver;
            this.ProdPrice.Location = new System.Drawing.Point(812, 343);
            this.ProdPrice.Name = "ProdPrice";
            this.ProdPrice.ReadOnly = true;
            this.ProdPrice.Size = new System.Drawing.Size(272, 40);
            this.ProdPrice.TabIndex = 34;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(432, 349);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 34);
            this.label15.TabIndex = 33;
            this.label15.Text = "Price";
            // 
            // ProdCount
            // 
            this.ProdCount.BackColor = System.Drawing.Color.Silver;
            this.ProdCount.Location = new System.Drawing.Point(812, 283);
            this.ProdCount.Name = "ProdCount";
            this.ProdCount.ReadOnly = true;
            this.ProdCount.Size = new System.Drawing.Size(272, 40);
            this.ProdCount.TabIndex = 32;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(432, 289);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(130, 34);
            this.label16.TabIndex = 31;
            this.label16.Text = "Count";
            // 
            // ProdName
            // 
            this.ProdName.BackColor = System.Drawing.Color.Silver;
            this.ProdName.Location = new System.Drawing.Point(812, 222);
            this.ProdName.Name = "ProdName";
            this.ProdName.ReadOnly = true;
            this.ProdName.Size = new System.Drawing.Size(272, 40);
            this.ProdName.TabIndex = 30;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label17.Location = new System.Drawing.Point(432, 228);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(272, 34);
            this.label17.TabIndex = 29;
            this.label17.Text = "Product Name";
            // 
            // PersonalArea
            // 
            this.PersonalArea.BackColor = System.Drawing.Color.OliveDrab;
            this.PersonalArea.Controls.Add(this.Next);
            this.PersonalArea.Controls.Add(this.Back);
            this.PersonalArea.Controls.Add(this.ShowP);
            this.PersonalArea.Controls.Add(this.ArrDateP);
            this.PersonalArea.Controls.Add(this.label9);
            this.PersonalArea.Controls.Add(this.IdRoomP);
            this.PersonalArea.Controls.Add(this.label8);
            this.PersonalArea.Controls.Add(this.ReservId);
            this.PersonalArea.Controls.Add(this.label7);
            this.PersonalArea.Controls.Add(this.PersPhone);
            this.PersonalArea.Controls.Add(this.label4);
            this.PersonalArea.Controls.Add(this.PersName);
            this.PersonalArea.Controls.Add(this.label5);
            this.PersonalArea.Controls.Add(this.PersSur);
            this.PersonalArea.Controls.Add(this.label6);
            this.PersonalArea.Location = new System.Drawing.Point(4, 89);
            this.PersonalArea.Name = "PersonalArea";
            this.PersonalArea.Padding = new System.Windows.Forms.Padding(3);
            this.PersonalArea.Size = new System.Drawing.Size(1389, 686);
            this.PersonalArea.TabIndex = 5;
            this.PersonalArea.Text = "Personal Area";
            // 
            // Next
            // 
            this.Next.BackColor = System.Drawing.Color.Silver;
            this.Next.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Next.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Next.Location = new System.Drawing.Point(762, 597);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(154, 43);
            this.Next.TabIndex = 28;
            this.Next.Text = "Next";
            this.Next.UseVisualStyleBackColor = false;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.Silver;
            this.Back.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Back.Location = new System.Drawing.Point(540, 597);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(154, 43);
            this.Back.TabIndex = 27;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // ShowP
            // 
            this.ShowP.BackColor = System.Drawing.Color.Silver;
            this.ShowP.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowP.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShowP.Location = new System.Drawing.Point(557, 316);
            this.ShowP.Name = "ShowP";
            this.ShowP.Size = new System.Drawing.Size(375, 43);
            this.ShowP.TabIndex = 26;
            this.ShowP.Text = "Show";
            this.ShowP.UseVisualStyleBackColor = false;
            this.ShowP.Click += new System.EventHandler(this.ShowP_Click);
            // 
            // ArrDateP
            // 
            this.ArrDateP.BackColor = System.Drawing.Color.Silver;
            this.ArrDateP.Location = new System.Drawing.Point(799, 516);
            this.ArrDateP.Name = "ArrDateP";
            this.ArrDateP.ReadOnly = true;
            this.ArrDateP.Size = new System.Drawing.Size(272, 40);
            this.ArrDateP.TabIndex = 25;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(419, 522);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(250, 34);
            this.label9.TabIndex = 24;
            this.label9.Text = "Arrival date";
            // 
            // IdRoomP
            // 
            this.IdRoomP.BackColor = System.Drawing.Color.Silver;
            this.IdRoomP.Location = new System.Drawing.Point(799, 456);
            this.IdRoomP.Name = "IdRoomP";
            this.IdRoomP.ReadOnly = true;
            this.IdRoomP.Size = new System.Drawing.Size(272, 40);
            this.IdRoomP.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(419, 462);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(159, 34);
            this.label8.TabIndex = 22;
            this.label8.Text = "Id Room";
            // 
            // ReservId
            // 
            this.ReservId.BackColor = System.Drawing.Color.Silver;
            this.ReservId.Location = new System.Drawing.Point(799, 395);
            this.ReservId.Name = "ReservId";
            this.ReservId.ReadOnly = true;
            this.ReservId.Size = new System.Drawing.Size(272, 40);
            this.ReservId.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(419, 401);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(275, 34);
            this.label7.TabIndex = 20;
            this.label7.Text = "Reservation Id";
            // 
            // PersPhone
            // 
            this.PersPhone.BackColor = System.Drawing.Color.Silver;
            this.PersPhone.Location = new System.Drawing.Point(799, 232);
            this.PersPhone.Name = "PersPhone";
            this.PersPhone.Size = new System.Drawing.Size(272, 40);
            this.PersPhone.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(419, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 34);
            this.label4.TabIndex = 18;
            this.label4.Text = "Phone";
            // 
            // PersName
            // 
            this.PersName.BackColor = System.Drawing.Color.Silver;
            this.PersName.Location = new System.Drawing.Point(799, 173);
            this.PersName.Name = "PersName";
            this.PersName.Size = new System.Drawing.Size(272, 40);
            this.PersName.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(419, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 34);
            this.label5.TabIndex = 16;
            this.label5.Text = "Name";
            // 
            // PersSur
            // 
            this.PersSur.BackColor = System.Drawing.Color.Silver;
            this.PersSur.Location = new System.Drawing.Point(799, 115);
            this.PersSur.Name = "PersSur";
            this.PersSur.Size = new System.Drawing.Size(272, 40);
            this.PersSur.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(419, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(167, 34);
            this.label6.TabIndex = 14;
            this.label6.Text = "Surname";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.OliveDrab;
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Location = new System.Drawing.Point(4, 89);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1389, 686);
            this.tabPage1.TabIndex = 7;
            this.tabPage1.Text = "Exit";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Silver;
            this.button5.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button5.Location = new System.Drawing.Point(423, 310);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(668, 134);
            this.button5.TabIndex = 24;
            this.button5.Text = "Exit";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.OliveDrab;
            this.tabPage2.Controls.Add(this.Med);
            this.tabPage2.Location = new System.Drawing.Point(4, 89);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1389, 686);
            this.tabPage2.TabIndex = 8;
            this.tabPage2.Text = "Medical Center";
            // 
            // Med
            // 
            this.Med.BackColor = System.Drawing.Color.Silver;
            this.Med.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Med.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Med.Location = new System.Drawing.Point(452, 307);
            this.Med.Name = "Med";
            this.Med.Size = new System.Drawing.Size(668, 134);
            this.Med.TabIndex = 25;
            this.Med.Text = "Go to Medical center";
            this.Med.UseVisualStyleBackColor = false;
            this.Med.Click += new System.EventHandler(this.Med_Click);
            // 
            // cn
            // 
            this.cn.ConnectionString = "Provider=SQLNCLI11;Data Source=LAPTOP-8JAMNBRV;Integrated Security=SSPI;Initial C" +
    "atalog=Hotel";
            // 
            // hotelDataSet
            // 
            this.hotelDataSet.DataSetName = "HotelDataSet";
            this.hotelDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Restaurant
            // 
            this.Restaurant.BackColor = System.Drawing.Color.OliveDrab;
            this.Restaurant.Controls.Add(this.button6);
            this.Restaurant.Location = new System.Drawing.Point(4, 89);
            this.Restaurant.Name = "Restaurant";
            this.Restaurant.Padding = new System.Windows.Forms.Padding(3);
            this.Restaurant.Size = new System.Drawing.Size(1389, 686);
            this.Restaurant.TabIndex = 9;
            this.Restaurant.Text = "Restaurant";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Silver;
            this.button6.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button6.Location = new System.Drawing.Point(451, 303);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(668, 134);
            this.button6.TabIndex = 26;
            this.button6.Text = "Go to a restaurant";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Guest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1397, 779);
            this.Controls.Add(this.ViewServices);
            this.Font = new System.Drawing.Font("Modern No. 20", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Guest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guest";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Guest_Load);
            this.ViewServices.ResumeLayout(false);
            this.RoomInfo.ResumeLayout(false);
            this.RoomInfo.PerformLayout();
            this.BookRoom.ResumeLayout(false);
            this.BookRoom.PerformLayout();
            this.ViewServi.ResumeLayout(false);
            this.ViewServi.PerformLayout();
            this.OrderService.ResumeLayout(false);
            this.OrderService.PerformLayout();
            this.BuyProducts.ResumeLayout(false);
            this.BuyProducts.PerformLayout();
            this.MyOrder.ResumeLayout(false);
            this.MyOrder.PerformLayout();
            this.PersonalArea.ResumeLayout(false);
            this.PersonalArea.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet)).EndInit();
            this.Restaurant.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl ViewServices;
        private System.Windows.Forms.TabPage BookRoom;
        private System.Windows.Forms.TabPage RoomInfo;
        private System.Windows.Forms.TabPage OrderService;
        private System.Windows.Forms.TabPage BuyProducts;
        private System.Windows.Forms.Label ThePresenceOfABathroom;
        private System.Windows.Forms.TextBox Bathroom;
        private System.Windows.Forms.Label ThePresenceOfATV;
        private System.Windows.Forms.Label CategName;
        private System.Windows.Forms.ComboBox CatName;
        private System.Windows.Forms.TextBox TV;
        private System.Windows.Forms.Label NumberOfRooms;
        private System.Windows.Forms.TextBox NumbOfRooms;
        private System.Windows.Forms.Label Cost;
        private System.Windows.Forms.TextBox CostPerNight;
        private System.Windows.Forms.Label Capacity;
        private System.Windows.Forms.TextBox RoomCapacity;
        private System.Windows.Forms.Label IdRo;
        private System.Data.OleDb.OleDbConnection cn;
        private System.Windows.Forms.Button ShowCat;
        private HotelDataSet hotelDataSet;
        public System.Windows.Forms.ListBox ListRoom;
        private System.Windows.Forms.Label ArrivalDate;
        private System.Windows.Forms.TextBox IdRoom;
        private System.Windows.Forms.Label IdRoomL;
        private System.Windows.Forms.MonthCalendar monthCalendar2;
        private System.Windows.Forms.Label DateOfDeparture;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.TextBox Surname;
        private System.Windows.Forms.Label SurnameL;
        private System.Windows.Forms.TextBox Phone;
        private System.Windows.Forms.Label PhoneL;
        private System.Windows.Forms.TextBox NameG;
        private System.Windows.Forms.Label NameL;
        private System.Windows.Forms.Button Booking;
        private System.Windows.Forms.Button OrderServiceB;
        private System.Windows.Forms.MonthCalendar monthCalendar3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label ResId;
        private System.Windows.Forms.TextBox ReservationId;
        private System.Windows.Forms.TabPage ViewServi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ServiceId;
        private System.Windows.Forms.Label CostL;
        private System.Windows.Forms.TextBox CostB;
        private System.Windows.Forms.Button ShowServ;
        private System.Windows.Forms.Label ServiceNameL;
        private System.Windows.Forms.ComboBox ServiceName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ServId;
        private System.Windows.Forms.TabPage PersonalArea;
        private System.Windows.Forms.TextBox ReservId;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox PersPhone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PersName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox PersSur;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button ShowP;
        private System.Windows.Forms.TextBox ArrDateP;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox IdRoomP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox Count;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox AvailableQuantity;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox UnitPrice;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ProdList;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox ReservIdProd;
        private System.Windows.Forms.TabPage MyOrder;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox TotalC;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox ProdPrice;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox ProdCount;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox ProdName;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button Med;
        private System.Windows.Forms.TabPage Restaurant;
        private System.Windows.Forms.Button button6;
    }
}

