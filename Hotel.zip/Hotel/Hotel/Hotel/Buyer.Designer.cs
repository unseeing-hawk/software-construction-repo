﻿
namespace Hotel
{
    partial class Buyer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Buyer));
            this.AddR = new System.Windows.Forms.TabControl();
            this.ListSupl = new System.Windows.Forms.TabPage();
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            this.button1 = new System.Windows.Forms.Button();
            this.Prod = new System.Windows.Forms.TabPage();
            this.label19 = new System.Windows.Forms.Label();
            this.dataGrid2 = new System.Windows.Forms.DataGrid();
            this.dg = new System.Windows.Forms.DataGrid();
            this.ShowCat = new System.Windows.Forms.Button();
            this.CategName = new System.Windows.Forms.Label();
            this.supl = new System.Windows.Forms.ComboBox();
            this.ViewServi = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.SupplierIdBuy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CountOfProducts = new System.Windows.Forms.TextBox();
            this.Label = new System.Windows.Forms.Label();
            this.ProductId = new System.Windows.Forms.TextBox();
            this.Buy = new System.Windows.Forms.Button();
            this.AService = new System.Windows.Forms.TabPage();
            this.dataGrid3 = new System.Windows.Forms.DataGrid();
            this.button2 = new System.Windows.Forms.Button();
            this.MyOrder = new System.Windows.Forms.TabPage();
            this.ShowRequests = new System.Windows.Forms.Button();
            this.SelectPurc = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SelectStat = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.AddStatus = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGrid4 = new System.Windows.Forms.DataGrid();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.cn = new System.Data.OleDb.OleDbConnection();
            this.AddR.SuspendLayout();
            this.ListSupl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            this.Prod.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
            this.ViewServi.SuspendLayout();
            this.AService.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid3)).BeginInit();
            this.MyOrder.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid4)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddR
            // 
            this.AddR.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.AddR.Controls.Add(this.ListSupl);
            this.AddR.Controls.Add(this.Prod);
            this.AddR.Controls.Add(this.ViewServi);
            this.AddR.Controls.Add(this.AService);
            this.AddR.Controls.Add(this.tabPage1);
            this.AddR.Controls.Add(this.MyOrder);
            this.AddR.Controls.Add(this.tabPage2);
            this.AddR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddR.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddR.ItemSize = new System.Drawing.Size(400, 41);
            this.AddR.Location = new System.Drawing.Point(0, 0);
            this.AddR.Multiline = true;
            this.AddR.Name = "AddR";
            this.AddR.SelectedIndex = 0;
            this.AddR.Size = new System.Drawing.Size(1222, 730);
            this.AddR.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.AddR.TabIndex = 2;
            // 
            // ListSupl
            // 
            this.ListSupl.BackColor = System.Drawing.Color.OliveDrab;
            this.ListSupl.Controls.Add(this.dataGrid1);
            this.ListSupl.Controls.Add(this.button1);
            this.ListSupl.ForeColor = System.Drawing.Color.Ivory;
            this.ListSupl.Location = new System.Drawing.Point(4, 89);
            this.ListSupl.Name = "ListSupl";
            this.ListSupl.Padding = new System.Windows.Forms.Padding(3);
            this.ListSupl.Size = new System.Drawing.Size(1214, 637);
            this.ListSupl.TabIndex = 1;
            this.ListSupl.Text = "List of suppliers";
            // 
            // dataGrid1
            // 
            this.dataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGrid1.DataMember = "";
            this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid1.Location = new System.Drawing.Point(77, 144);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.ReadOnly = true;
            this.dataGrid1.RowHeaderWidth = 70;
            this.dataGrid1.Size = new System.Drawing.Size(1028, 468);
            this.dataGrid1.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(457, 83);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(540, 43);
            this.button1.TabIndex = 19;
            this.button1.Text = "Show";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Prod
            // 
            this.Prod.AutoScroll = true;
            this.Prod.BackColor = System.Drawing.Color.OliveDrab;
            this.Prod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Prod.Controls.Add(this.label19);
            this.Prod.Controls.Add(this.dataGrid2);
            this.Prod.Controls.Add(this.dg);
            this.Prod.Controls.Add(this.ShowCat);
            this.Prod.Controls.Add(this.CategName);
            this.Prod.Controls.Add(this.supl);
            this.Prod.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Prod.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.Prod.ImageKey = "(отсутствует)";
            this.Prod.Location = new System.Drawing.Point(4, 45);
            this.Prod.Name = "Prod";
            this.Prod.Padding = new System.Windows.Forms.Padding(3);
            this.Prod.Size = new System.Drawing.Size(1214, 681);
            this.Prod.TabIndex = 0;
            this.Prod.Text = "List of products from supplier";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Castellar", 17.8F);
            this.label19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label19.Location = new System.Drawing.Point(896, 92);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(380, 36);
            this.label19.TabIndex = 18;
            this.label19.Text = "Hotel product list";
            // 
            // dataGrid2
            // 
            this.dataGrid2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGrid2.DataMember = "";
            this.dataGrid2.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid2.Location = new System.Drawing.Point(754, 206);
            this.dataGrid2.Name = "dataGrid2";
            this.dataGrid2.ReadOnly = true;
            this.dataGrid2.RowHeaderWidth = 70;
            this.dataGrid2.Size = new System.Drawing.Size(389, 468);
            this.dataGrid2.TabIndex = 17;
            // 
            // dg
            // 
            this.dg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dg.DataMember = "";
            this.dg.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dg.Location = new System.Drawing.Point(181, 206);
            this.dg.Name = "dg";
            this.dg.ReadOnly = true;
            this.dg.RowHeaderWidth = 70;
            this.dg.Size = new System.Drawing.Size(398, 468);
            this.dg.TabIndex = 16;
            // 
            // ShowCat
            // 
            this.ShowCat.BackColor = System.Drawing.Color.Silver;
            this.ShowCat.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowCat.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShowCat.Location = new System.Drawing.Point(491, 157);
            this.ShowCat.Name = "ShowCat";
            this.ShowCat.Size = new System.Drawing.Size(472, 43);
            this.ShowCat.TabIndex = 15;
            this.ShowCat.Text = "Show";
            this.ShowCat.UseVisualStyleBackColor = false;
            this.ShowCat.Click += new System.EventHandler(this.ShowCat_Click);
            // 
            // CategName
            // 
            this.CategName.AutoSize = true;
            this.CategName.Font = new System.Drawing.Font("Castellar", 17.8F);
            this.CategName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.CategName.Location = new System.Drawing.Point(237, 95);
            this.CategName.Name = "CategName";
            this.CategName.Size = new System.Drawing.Size(322, 36);
            this.CategName.TabIndex = 3;
            this.CategName.Text = "Select a supplier";
            // 
            // supl
            // 
            this.supl.BackColor = System.Drawing.Color.Silver;
            this.supl.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.supl.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supl.FormattingEnabled = true;
            this.supl.Items.AddRange(new object[] {
            "Booking",
            "Client info",
            "Room info",
            "Categories info",
            "Orders",
            "About orders",
            "Service catalog",
            "Service request",
            "Product list",
            "About status",
            "Employees"});
            this.supl.Location = new System.Drawing.Point(565, 86);
            this.supl.Name = "supl";
            this.supl.Size = new System.Drawing.Size(105, 48);
            this.supl.TabIndex = 2;
            // 
            // ViewServi
            // 
            this.ViewServi.BackColor = System.Drawing.Color.OliveDrab;
            this.ViewServi.Controls.Add(this.label3);
            this.ViewServi.Controls.Add(this.SupplierIdBuy);
            this.ViewServi.Controls.Add(this.label1);
            this.ViewServi.Controls.Add(this.CountOfProducts);
            this.ViewServi.Controls.Add(this.Label);
            this.ViewServi.Controls.Add(this.ProductId);
            this.ViewServi.Controls.Add(this.Buy);
            this.ViewServi.Location = new System.Drawing.Point(4, 45);
            this.ViewServi.Name = "ViewServi";
            this.ViewServi.Padding = new System.Windows.Forms.Padding(3);
            this.ViewServi.Size = new System.Drawing.Size(1214, 681);
            this.ViewServi.TabIndex = 4;
            this.ViewServi.Text = "Buy products";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(374, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(213, 36);
            this.label3.TabIndex = 29;
            this.label3.Text = "Supplier Id";
            // 
            // SupplierIdBuy
            // 
            this.SupplierIdBuy.BackColor = System.Drawing.Color.Silver;
            this.SupplierIdBuy.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SupplierIdBuy.Location = new System.Drawing.Point(798, 149);
            this.SupplierIdBuy.Name = "SupplierIdBuy";
            this.SupplierIdBuy.Size = new System.Drawing.Size(344, 44);
            this.SupplierIdBuy.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(374, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(383, 36);
            this.label1.TabIndex = 27;
            this.label1.Text = "Count Of Products";
            // 
            // CountOfProducts
            // 
            this.CountOfProducts.BackColor = System.Drawing.Color.Silver;
            this.CountOfProducts.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountOfProducts.Location = new System.Drawing.Point(798, 322);
            this.CountOfProducts.Name = "CountOfProducts";
            this.CountOfProducts.Size = new System.Drawing.Size(344, 44);
            this.CountOfProducts.TabIndex = 26;
            // 
            // Label
            // 
            this.Label.AutoSize = true;
            this.Label.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Label.Location = new System.Drawing.Point(374, 243);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(229, 36);
            this.Label.TabIndex = 25;
            this.Label.Text = "Product Id";
            // 
            // ProductId
            // 
            this.ProductId.BackColor = System.Drawing.Color.Silver;
            this.ProductId.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductId.Location = new System.Drawing.Point(798, 235);
            this.ProductId.Name = "ProductId";
            this.ProductId.Size = new System.Drawing.Size(344, 44);
            this.ProductId.TabIndex = 24;
            // 
            // Buy
            // 
            this.Buy.BackColor = System.Drawing.Color.Silver;
            this.Buy.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Buy.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Buy.Location = new System.Drawing.Point(510, 473);
            this.Buy.Name = "Buy";
            this.Buy.Size = new System.Drawing.Size(456, 83);
            this.Buy.TabIndex = 23;
            this.Buy.Text = "Buy";
            this.Buy.UseVisualStyleBackColor = false;
            this.Buy.Click += new System.EventHandler(this.Buy_Click);
            // 
            // AService
            // 
            this.AService.BackColor = System.Drawing.Color.OliveDrab;
            this.AService.Controls.Add(this.dataGrid3);
            this.AService.Controls.Add(this.button2);
            this.AService.Location = new System.Drawing.Point(4, 89);
            this.AService.Name = "AService";
            this.AService.Padding = new System.Windows.Forms.Padding(3);
            this.AService.Size = new System.Drawing.Size(1214, 637);
            this.AService.TabIndex = 2;
            this.AService.Text = "Purchases By Buyer";
            // 
            // dataGrid3
            // 
            this.dataGrid3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGrid3.DataMember = "";
            this.dataGrid3.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid3.Location = new System.Drawing.Point(93, 115);
            this.dataGrid3.Name = "dataGrid3";
            this.dataGrid3.ReadOnly = true;
            this.dataGrid3.RowHeaderWidth = 70;
            this.dataGrid3.Size = new System.Drawing.Size(1028, 468);
            this.dataGrid3.TabIndex = 22;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Silver;
            this.button2.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(473, 54);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(540, 43);
            this.button2.TabIndex = 21;
            this.button2.Text = "Show";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // MyOrder
            // 
            this.MyOrder.BackColor = System.Drawing.Color.OliveDrab;
            this.MyOrder.Controls.Add(this.ShowRequests);
            this.MyOrder.Controls.Add(this.SelectPurc);
            this.MyOrder.Controls.Add(this.label2);
            this.MyOrder.Controls.Add(this.SelectStat);
            this.MyOrder.Controls.Add(this.label6);
            this.MyOrder.Controls.Add(this.AddStatus);
            this.MyOrder.Location = new System.Drawing.Point(4, 89);
            this.MyOrder.Name = "MyOrder";
            this.MyOrder.Padding = new System.Windows.Forms.Padding(3);
            this.MyOrder.Size = new System.Drawing.Size(1214, 637);
            this.MyOrder.TabIndex = 6;
            this.MyOrder.Text = " Install Status";
            // 
            // ShowRequests
            // 
            this.ShowRequests.BackColor = System.Drawing.Color.Silver;
            this.ShowRequests.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShowRequests.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ShowRequests.Location = new System.Drawing.Point(502, 71);
            this.ShowRequests.Name = "ShowRequests";
            this.ShowRequests.Size = new System.Drawing.Size(578, 104);
            this.ShowRequests.TabIndex = 46;
            this.ShowRequests.Text = "Show all purchases";
            this.ShowRequests.UseVisualStyleBackColor = false;
            this.ShowRequests.Click += new System.EventHandler(this.ShowRequests_Click);
            // 
            // SelectPurc
            // 
            this.SelectPurc.BackColor = System.Drawing.Color.Silver;
            this.SelectPurc.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SelectPurc.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectPurc.FormattingEnabled = true;
            this.SelectPurc.Items.AddRange(new object[] {
            "Booking",
            "Client info",
            "Room info",
            "Categories info",
            "Orders",
            "About orders",
            "Service catalog",
            "Service request",
            "Product list",
            "About status",
            "Employees"});
            this.SelectPurc.Location = new System.Drawing.Point(861, 332);
            this.SelectPurc.Name = "SelectPurc";
            this.SelectPurc.Size = new System.Drawing.Size(344, 48);
            this.SelectPurc.TabIndex = 45;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(367, 344);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(311, 36);
            this.label2.TabIndex = 44;
            this.label2.Text = "Select purchase";
            // 
            // SelectStat
            // 
            this.SelectStat.BackColor = System.Drawing.Color.Silver;
            this.SelectStat.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SelectStat.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectStat.FormattingEnabled = true;
            this.SelectStat.Items.AddRange(new object[] {
            "Booking",
            "Client info",
            "Room info",
            "Categories info",
            "Orders",
            "About orders",
            "Service catalog",
            "Service request",
            "Product list",
            "About status",
            "Employees"});
            this.SelectStat.Location = new System.Drawing.Point(861, 250);
            this.SelectStat.Name = "SelectStat";
            this.SelectStat.Size = new System.Drawing.Size(344, 48);
            this.SelectStat.TabIndex = 43;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Castellar", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(367, 262);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(260, 36);
            this.label6.TabIndex = 42;
            this.label6.Text = "Select status";
            // 
            // AddStatus
            // 
            this.AddStatus.BackColor = System.Drawing.Color.Silver;
            this.AddStatus.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddStatus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AddStatus.Location = new System.Drawing.Point(585, 448);
            this.AddStatus.Name = "AddStatus";
            this.AddStatus.Size = new System.Drawing.Size(330, 104);
            this.AddStatus.TabIndex = 28;
            this.AddStatus.Text = "Save";
            this.AddStatus.UseVisualStyleBackColor = false;
            this.AddStatus.Click += new System.EventHandler(this.AddStatus_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.OliveDrab;
            this.tabPage1.Controls.Add(this.dataGrid4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.tabPage1.Location = new System.Drawing.Point(4, 89);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1214, 637);
            this.tabPage1.TabIndex = 7;
            this.tabPage1.Text = "See status Descryption";
            // 
            // dataGrid4
            // 
            this.dataGrid4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGrid4.DataMember = "";
            this.dataGrid4.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dataGrid4.Location = new System.Drawing.Point(93, 115);
            this.dataGrid4.Name = "dataGrid4";
            this.dataGrid4.ReadOnly = true;
            this.dataGrid4.RowHeaderWidth = 70;
            this.dataGrid4.Size = new System.Drawing.Size(1028, 468);
            this.dataGrid4.TabIndex = 24;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Silver;
            this.button3.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button3.Location = new System.Drawing.Point(473, 54);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(540, 43);
            this.button3.TabIndex = 23;
            this.button3.Text = "Show";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.OliveDrab;
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Location = new System.Drawing.Point(4, 89);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1214, 637);
            this.tabPage2.TabIndex = 8;
            this.tabPage2.Text = "Exit";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Silver;
            this.button4.Font = new System.Drawing.Font("Castellar", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button4.Location = new System.Drawing.Point(476, 288);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(668, 134);
            this.button4.TabIndex = 24;
            this.button4.Text = "Exit";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // cn
            // 
            this.cn.ConnectionString = "Provider=SQLNCLI11;Data Source=LAPTOP-8JAMNBRV;Integrated Security=SSPI;Initial C" +
    "atalog=Hotel";
            // 
            // Buyer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1222, 730);
            this.Controls.Add(this.AddR);
            this.Font = new System.Drawing.Font("Modern No. 20", 7.8F);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Buyer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Buyer";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Buyer_Load);
            this.AddR.ResumeLayout(false);
            this.ListSupl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            this.Prod.ResumeLayout(false);
            this.Prod.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
            this.ViewServi.ResumeLayout(false);
            this.ViewServi.PerformLayout();
            this.AService.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid3)).EndInit();
            this.MyOrder.ResumeLayout(false);
            this.MyOrder.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid4)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl AddR;
        private System.Windows.Forms.TabPage Prod;
        private System.Windows.Forms.DataGrid dg;
        private System.Windows.Forms.Button ShowCat;
        private System.Windows.Forms.Label CategName;
        private System.Windows.Forms.ComboBox supl;
        private System.Windows.Forms.TabPage ListSupl;
        private System.Windows.Forms.TabPage ViewServi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CountOfProducts;
        private System.Windows.Forms.Label Label;
        private System.Windows.Forms.TextBox ProductId;
        private System.Windows.Forms.Button Buy;
        private System.Windows.Forms.TabPage MyOrder;
        private System.Windows.Forms.Button AddStatus;
        private System.Windows.Forms.DataGrid dataGrid1;
        private System.Windows.Forms.Button button1;
        private System.Data.OleDb.OleDbConnection cn;
        private System.Windows.Forms.DataGrid dataGrid2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TabPage AService;
        private System.Windows.Forms.DataGrid dataGrid3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox SupplierIdBuy;
        private System.Windows.Forms.ComboBox SelectStat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox SelectPurc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ShowRequests;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGrid dataGrid4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button4;
    }
}