﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hotel
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void AddRoom_Click(object sender, EventArgs e)
        {
            if ((Login.TextLength == 0) || (Password.TextLength == 0))
            {
                MessageBox.Show("Not all data entered!", "ERROR", MessageBoxButtons.OK);
            }
            else
            {
                if ((Login.Text == "admin") || (Login.Text == "Admin"))
                {
                    if(Password.Text == "admin")
                    {
                        Admin adm = new Admin();
                        Hide();
                        adm.ShowDialog();
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Wrong password!", "ERROR", MessageBoxButtons.OK);
                    }
                }
                else if ((Login.Text == "guest") || (Login.Text == "Guest"))
                {
                    if (Password.Text == "guest")
                    {
                        Guest guest = new Guest();
                        Hide();
                        guest.ShowDialog();
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Wrong password!", "ERROR", MessageBoxButtons.OK);
                    }
                }

                else if ((Login.Text == "buyer") || (Login.Text == "Buyer"))
                {
                    if (Password.Text == "buyer")
                    {
                        Buyer buyer = new Buyer();
                        Hide();
                        buyer.ShowDialog();
                        Close();
                    }
                    else
                    {
                        MessageBox.Show("Wrong password!", "ERROR", MessageBoxButtons.OK);
                    }
                }
                else
                {
                    MessageBox.Show("Wrong Login!", "ERROR", MessageBoxButtons.OK);
                }
            }
        }


    }
}
